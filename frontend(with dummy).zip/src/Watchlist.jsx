import React, { useMemo, useState, useEffect } from "react";
import "./Watchlist.css";
import RecommendationModal from "./RecommendationModal";

const ArrowUpRight = () => <span aria-hidden>📈</span>;
const ArrowDownRight = () => <span aria-hidden>📉</span>;
const SearchIcon = () => <span aria-hidden>🔍</span>;

function Watchlist({ portfolio, setPortfolio, wallet, setWallet, addTransaction }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStock, setSelectedStock] = useState(null);
  const [quantity, setQuantity] = useState("");
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [purchasedStock, setPurchasedStock] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [showReco, setShowReco] = useState(false);

  // ✅ Persisted tracked stocks
  const [trackedIds, setTrackedIds] = useState(() => {
    try {
      const saved = localStorage.getItem("trackedIds");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("trackedIds", JSON.stringify(trackedIds));
  }, [trackedIds]);

  // Demo stock data
  const [allStocks] = useState([
    { id: 1, symbol: "AAPL", name: "Apple Inc.", price: 185.43, change: 2.15, changePercent: 1.17, volume: "45,200,000" },
    { id: 2, symbol: "GOOGL", name: "Alphabet Inc.", price: 142.56, change: -1.23, changePercent: -0.85, volume: "28,400,000" },
    { id: 3, symbol: "MSFT", name: "Microsoft Corporation", price: 412.78, change: 5.67, changePercent: 1.39, volume: "32,100,000" },
    { id: 4, symbol: "TSLA", name: "Tesla, Inc.", price: 238.92, change: -8.45, changePercent: -3.42, volume: "95,600,000" },
    { id: 5, symbol: "AMZN", name: "Amazon.com Inc.", price: 156.78, change: 3.22, changePercent: 2.09, volume: "41,800,000" },
    { id: 6, symbol: "NVDA", name: "NVIDIA Corporation", price: 891.34, change: 12.56, changePercent: 1.43, volume: "52,300,000" },
    { id: 7, symbol: "META", name: "Meta Platforms Inc.", price: 484.67, change: -2.34, changePercent: -0.48, volume: "18,900,000" },
    { id: 8, symbol: "BTC", name: "Bitcoin", price: 67432.12, change: 1234.56, changePercent: 1.87, volume: "N/A" }
  ]);

  // 🔎 Search logic
  const filteredStocks = useMemo(() => {
    const t = searchTerm.trim().toLowerCase();
    if (!t) return allStocks;
    return allStocks.filter(
      (s) => s.symbol.toLowerCase().includes(t) || s.name.toLowerCase().includes(t)
    );
  }, [searchTerm, allStocks]);

  // ✅ Tracked stocks only
  const trackedStocks = useMemo(
    () => allStocks.filter((s) => trackedIds.includes(s.id)),
    [allStocks, trackedIds]
  );

  // Track / untrack helpers
  const trackStock = (id) => {
    setTrackedIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
  };
  const removeTracked = (id) => {
    setTrackedIds((prev) => prev.filter((x) => x !== id));
  };

  // Buy modal logic
  const openBuyModal = (stockId) => {
    const stock = allStocks.find((s) => s.id === stockId);
    setSelectedStock(stock);
    setQuantity("");
    setShowBuyModal(true);
  };
  const closeBuyModal = () => {
    setShowBuyModal(false);
    setSelectedStock(null);
    setQuantity("");
  };

  const executePurchase = () => {
    if (!selectedStock || !quantity) return;
    const numQuantity = Number(quantity);

    if (isNaN(numQuantity) || numQuantity <= 0) {
      setErrorMessage("Enter a valid number of shares.");
      setShowErrorModal(true);
      return;
    }

    const totalCost = selectedStock.price * numQuantity;
    if (wallet >= totalCost) {
      setWallet(wallet - totalCost);

      const existing = portfolio.find((p) => p.stockId === selectedStock.id);
      if (existing) {
        const newShares = existing.shares + numQuantity;
        const newAvgPrice =
          (existing.avgPrice * existing.shares + totalCost) / newShares;
        setPortfolio(
          portfolio.map((p) =>
            p.stockId === selectedStock.id
              ? { ...p, shares: newShares, avgPrice: newAvgPrice }
              : p
          )
        );
      } else {
        setPortfolio([
          ...portfolio,
          {
            stockId: selectedStock.id,
            symbol: selectedStock.symbol,
            shares: numQuantity,
            avgPrice: selectedStock.price,
          },
        ]);
      }

      if (typeof addTransaction === "function") {
        addTransaction("BUY", selectedStock, numQuantity, selectedStock.price);
      }

      setPurchasedStock({ ...selectedStock, quantity: numQuantity, totalCost });
      setShowSuccessModal(true);
      closeBuyModal();
    } else {
      setErrorMessage(
        `Insufficient funds! You need ₹${totalCost.toFixed(
          2
        )} but only have ₹${wallet.toFixed(2)}.`
      );
      setShowErrorModal(true);
    }
  };

  const portfolioCount = portfolio?.length ?? 0;
  const totalPositions = portfolio?.reduce((a, p) => a + (p.shares || 0), 0) ?? 0;

  return (
    <div className="wl-root">
      {/* Top bar */}
      <header className="wl-topbar">
        <div className="wl-titlewrap">
          <h1 className="wl-title">Watchlist</h1>
          <span className="wl-title-glow" aria-hidden />
        </div>

        <div className="wl-stats">
          <div className="chip chip-blue" title="Cash in wallet">
            <span className="chip-label">Wallet</span>
            <span className="chip-value">₹{wallet.toLocaleString()}</span>
          </div>
          <div className="chip chip-green" title="Positions tracked">
            <span className="chip-label">Positions</span>
            <span className="chip-value">{portfolioCount}</span>
          </div>
          <div className="chip chip-white" title="Total shares">
            <span className="chip-label">Shares</span>
            <span className="chip-value">{totalPositions}</span>
          </div>
        </div>
      </header>

      {/* Search */}
      <section className="wl-search">
        <div className="wl-searchbox">
          <SearchIcon />
          <input
            aria-label="Search stocks"
            placeholder="Search by symbol or name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <span className="wl-focusring" aria-hidden />
        </div>

        {searchTerm.trim() && (
          <div className="wl-results">
            {filteredStocks.map((s) => {
              const already = trackedIds.includes(s.id);
              return (
                <div key={`sr-${s.id}`} className="wl-result-row">
                  <div className="wl-result-left">
                    <span className="sym">{s.symbol}</span>
                    <span className="name">{s.name}</span>
                  </div>
                  <div className="wl-result-right">
                    <span className="wl-price">₹{s.price.toLocaleString()}</span>
                    <button
                      className={`btn ${already ? "btn-disabled" : "btn-buy"}`}
                      onClick={() => !already && trackStock(s.id)}
                      disabled={already}
                      title={already ? "Tracked" : "Track this stock"}
                    >
                      {already ? "Tracked" : "Track"}
                    </button>
                  </div>
                </div>
              );
            })}
            {filteredStocks.length === 0 && (
              <div className="wl-empty">No matches. Try another symbol/name.</div>
            )}
          </div>
        )}
      </section>

      {/* Table */}
      <section className="wl-card">
        <div className="wl-table-head" role="row">
          <span>Stock</span>
          <span>Price</span>
          <span>Change</span>
          <span>Volume</span>
          <span className="right">Action</span>
        </div>

        <div className="wl-table-body">
          {trackedStocks.map((stock) => {
            const up = stock.change >= 0;
            return (
              <div
                key={`${stock.id}-${stock.symbol}`}
                role="row"
                className="wl-row"
              >
                {/* Stock */}
                <div className="wl-cell stock">
                  <div className={`trend-dot ${up ? "up" : "down"}`}>
                    {up ? <ArrowUpRight /> : <ArrowDownRight />}
                  </div>
                  <div className="stock-meta">
                    <div className="sym">{stock.symbol}</div>
                    <div className="name">{stock.name}</div>
                  </div>
                </div>

                {/* Price */}
                <div className="wl-cell price">
                  ₹{stock.price.toLocaleString()}
                </div>

                {/* Change */}
                <div className="wl-cell">
                  <span className={`badge ${up ? "badge-up" : "badge-down"}`}>
                    {stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)
                  </span>
                </div>

                {/* Volume */}
                <div className="wl-cell vol">{stock.volume}</div>

                {/* Action */}
                <div className="wl-cell action">
                  <button
                    className="btn btn-buy"
                    onClick={() => openBuyModal(stock.id)}
                  >
                    <span className="btn-ink" aria-hidden />
                    + Buy
                  </button>
                  <button
                    className="btn btn-cancel"
                    onClick={() => removeTracked(stock.id)}
                    style={{ marginLeft: 8 }}
                    title="Remove from watchlist"
                  >
                    Remove
                  </button>
                </div>
              </div>
            );
          })}

          {trackedStocks.length === 0 && (
            <div className="wl-empty">
              Your watchlist is empty. Search a stock above and click <strong>Track</strong>.
            </div>
          )}
        </div>
      </section>

      {/* Buy Modal */}
      {showBuyModal && selectedStock && (
        <div className="wl-backdrop" role="dialog" aria-modal="true">
          <div className="wl-modal">
            <div className="wl-modal-head">
              <div className="tick blue" aria-hidden />
              <div className="wl-modal-title">
                Buy <strong>{selectedStock.symbol}</strong>
              </div>
            </div>

            <div className="wl-modal-sub">{selectedStock.name}</div>
            <div className="wl-modal-price">
              Price per share: <strong>₹{selectedStock.price.toFixed(2)}</strong>
            </div>

            <div className="wl-input">
              <input
                type="number"
                min="1"
                step="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="Number of shares"
              />
              <span className="wl-focusring" aria-hidden />
            </div>

            {quantity && (
              <div className="wl-total">
                Total:{" "}
                <strong>
                  ₹{(selectedStock.price * Number(quantity)).toFixed(2)}
                </strong>
              </div>
            )}

            <div className="wl-modal-actions">
              <button className="btn btn-confirm" onClick={executePurchase}>
                <span className="btn-ink" aria-hidden />
                Buy
              </button>
              <button className="btn btn-cancel" onClick={closeBuyModal}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccessModal && purchasedStock && (
        <div className="wl-backdrop" role="dialog" aria-modal="true">
          <div className="wl-modal success">
            <div className="wl-modal-head">
              <div className="tick green" aria-hidden />
              <div className="wl-modal-title">Purchase Successful</div>
            </div>

            <div className="wl-modal-sub">
              You bought <strong>{purchasedStock.quantity}</strong> shares of{" "}
              <strong>{purchasedStock.symbol}</strong>
            </div>
            <div className="wl-total">
              Total Spent:{" "}
              <strong>₹{purchasedStock.totalCost.toFixed(2)}</strong>
            </div>

            <div className="wl-modal-actions">
              <button
                className="btn btn-confirm"
                onClick={() => {
                  setShowSuccessModal(false);
                  setShowReco(true);
                }}
              >
                <span className="btn-ink" aria-hidden />
                Awesome
              </button>
            </div>

            <div className="confetti" aria-hidden />
          </div>
        </div>
      )}

      {/* Error Modal */}
      {showErrorModal && (
        <div className="wl-backdrop" role="dialog" aria-modal="true">
          <div className="wl-modal error">
            <div className="wl-modal-head">
              <div className="tick red" aria-hidden />
              <div className="wl-modal-title">Error</div>
            </div>

            <div className="wl-modal-sub">{errorMessage}</div>

            <div className="wl-modal-actions">
              <button
                className="btn btn-cancel"
                onClick={() => setShowErrorModal(false)}
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ✅ Recommendation Modal now uses purchasedStock */}
      {showReco && purchasedStock && (
        <RecommendationModal
          stock={purchasedStock}
          type="buy"
          onClose={() => setShowReco(false)}
          onSell={() => {}}
        />
      )}
    </div>
  );
}

export default Watchlist;
