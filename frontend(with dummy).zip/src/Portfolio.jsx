import React, { useState, useMemo, useEffect, useRef } from "react";
import "./Portfolio.css";
import RecommendationModal from "./RecommendationModal";

/*
  Portfolio.jsx
  - Uses addTransaction (passed from App.js) to log buy/sell
  - Keeps wallet/portfolio in sync
  - Uses hardcoded stock list inside Portfolio
*/

function useAnimatedNumber(value, duration = 700) {
  const [display, setDisplay] = useState(value);
  const rafRef = useRef(null);
  const startRef = useRef(null);
  const fromRef = useRef(value);
  

  useEffect(() => {
    cancelAnimationFrame(rafRef.current);
    fromRef.current = display;
    const start = performance.now();
    startRef.current = start;
    const diff = value - fromRef.current;
    const animate = (now) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3); // easeOutCubic
      setDisplay(fromRef.current + diff * eased);
      if (t < 1) rafRef.current = requestAnimationFrame(animate);
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, duration]);

  return display;
}

export default function Portfolio({
  portfolio,
  setPortfolio,
  wallet,
  setWallet,
  addTransaction, // ✅ comes from App.js
}) {
  const [selectedStock, setSelectedStock] = useState(null);
  const [selectedHolding, setSelectedHolding] = useState(null);
  const [quantity, setQuantity] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState("");
  const [modalError, setModalError] = useState("");
  const [showReco, setShowReco] = useState(false);

  // ✅ Hardcoded stock list
  const allStocks = [
    { id: 1, symbol: "AAPL", name: "Apple Inc.", price: 185.43 },
    { id: 2, symbol: "GOOGL", name: "Alphabet Inc.", price: 138.21 },
    { id: 3, symbol: "MSFT", name: "Microsoft Corp.", price: 412.78 },
    { id: 4, symbol: "TSLA", name: "Tesla Inc.", price: 248.5 },
    { id: 5, symbol: "NVDA", name: "NVIDIA Corp.", price: 875.28 },
  ];

  // totals derived
  const totals = useMemo(() => {
    let totalValue = 0;
    let totalInvested = 0;
    portfolio.forEach((h) => {
      const s = allStocks.find((a) => a.id === h.stockId);
      if (!s) return;
      totalValue += s.price * h.shares;
      totalInvested += h.avgPrice * h.shares;
    });
    const totalPnL = totalValue - totalInvested;
    const totalReturn =
      totalInvested > 0 ? (totalPnL / totalInvested) * 100 : 0;
    return { totalValue, totalInvested, totalPnL, totalReturn };
  }, [portfolio, allStocks]);

  // animated displays
  const animatedTotalValue = useAnimatedNumber(totals.totalValue, 900);
  const animatedPnL = useAnimatedNumber(totals.totalPnL, 900);
  const animatedReturn = useAnimatedNumber(totals.totalReturn, 900);

  const formatCurrency = (n) => {
    if (Number.isNaN(n) || n === undefined) return "$0.00";
    return `${n < 0 ? "-" : ""}₹${Math.abs(n).toFixed(2)}`;
  };

  // modal helpers
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") closeModal();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const openModal = (type, stockId) => {
    const stock = allStocks.find((s) => s.id === stockId);
    const holding = portfolio.find((p) => p.stockId === stockId);
    setSelectedStock(stock);
    setSelectedHolding(holding || null);
    setQuantity("");
    setModalError("");
    setModalType(type);
    setShowModal(true);
    document.body.style.overflow = "hidden";
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedStock(null);
    setSelectedHolding(null);
    setQuantity("");
    setModalError("");
    document.body.style.overflow = "";
  };

  const executeTransaction = () => {
    if (!selectedStock || !quantity) {
      setModalError("Please enter a quantity.");
      return;
    }
    const numQuantity = Number(quantity);
    if (!Number.isFinite(numQuantity) || numQuantity <= 0) {
      setModalError("Quantity must be a positive number.");
      return;
    }

    if (modalType === "buy") {
      const cost = selectedStock.price * numQuantity;
      if (wallet < cost) {
        setModalError(
          `Insufficient funds: ₹${formatCurrency(wallet)} available.`
        );
        return;
      }

      setWallet((w) => +(w - cost).toFixed(2));

      const existing = portfolio.find((p) => p.stockId === selectedStock.id);
      if (existing) {
        const newShares = existing.shares + numQuantity;
        const newAvg =
          (existing.avgPrice * existing.shares + cost) / newShares;
        setPortfolio((prev) =>
          prev.map((p) =>
            p.stockId === selectedStock.id
              ? { ...p, shares: newShares, avgPrice: newAvg }
              : p
          )
        );
      } else {
        setPortfolio((prev) => [
          ...prev,
          {
            stockId: selectedStock.id,
            symbol: selectedStock.symbol,
            shares: numQuantity,
            avgPrice: selectedStock.price,
          },
        ]);
      }

      // ✅ log transaction safely
      if (typeof addTransaction === "function") {
        addTransaction("BUY", selectedStock, numQuantity, selectedStock.price);
      
      }
      closeModal();
       setShowReco(true);
    } else {
      if (!selectedHolding || numQuantity > selectedHolding.shares) {
        setModalError(
          `You can only sell up to ${selectedHolding?.shares || 0} shares.`
        );
        return;
      }

      const revenue = selectedStock.price * numQuantity;
      setWallet((w) => +(w + revenue).toFixed(2));

      if (numQuantity === selectedHolding.shares) {
        setPortfolio((prev) =>
          prev.filter((p) => p.stockId !== selectedStock.id)
        );
      } else {
        setPortfolio((prev) =>
          prev.map((p) =>
            p.stockId === selectedStock.id
              ? { ...p, shares: p.shares - numQuantity }
              : p
          )
        );
      }

      // ✅ log transaction safely
      if (typeof addTransaction === "function") {
        addTransaction(
          "SELL",
          selectedStock,
          numQuantity,
          selectedStock.price
        );
     

      }
    }

    closeModal();
     setShowReco(true);
  };

  return (
    <div className="portfolio-wrap ultra">
      <header className="portfolio-top">
        <div className="brand-title">
          <div className="logo-blob" aria-hidden>
            <svg
              viewBox="0 0 24 24"
              width="18"
              height="18"
              fill="none"
              stroke="currentColor"
            >
              <path
                d="M3 12h3l2-4 4 8 4-6 4 4"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <div>
            <h1>Portfolio</h1>
            <p className="subtitle">
              Track your investments & performance — ultra polished
            </p>
          </div>
        </div>

        <div className="summary-cards">
          <div className="card floaty">
            <div className="card-left">
              <div className="card-label">Total Value</div>
              <div className="card-value large">
                <span className="animated-money">
                  {formatCurrency(animatedTotalValue)}
                </span>
              </div>
            </div>
            <div className="card-icon wallet" title="Total portfolio value">
              💰
            </div>
          </div>

          <div className="card floaty">
            <div className="card-left">
              <div className="card-label">Total P&amp;L</div>
              <div
                className={`card-value ${
                  totals.totalPnL >= 0 ? "green" : "red"
                }`}
              >
                <span className="animated-money">
                  {totals.totalPnL >= 0 ? "+" : "-"}
                  {formatCurrency(Math.abs(animatedPnL))}
                </span>
              </div>
            </div>
            <div className="card-icon trend">📈</div>
          </div>

          <div className="card floaty">
            <div className="card-left">
              <div className="card-label">Total Return</div>
              <div
                className={`card-value ${
                  totals.totalReturn >= 0 ? "green" : "red"
                }`}
              >
                <span className="animated-money">
                  {animatedReturn.toFixed(2)}%
                </span>
              </div>
            </div>
            <div className="card-icon pct">📊</div>
          </div>
        </div>
      </header>

      <main className="portfolio-main">
        <div className="wallet-strip">
          <div>Wallet Balance</div>
          <div className="wallet-amount">{formatCurrency(wallet)}</div>
        </div>

        <section className="holdings-card ultra-card">
          <div className="holdings-header">
            <h2>Holdings</h2>
          </div>

          <div className="holdings-table">
            <div className="table-head">
              <div>Stock Name</div>
              <div>Total Quantity</div>
              <div>Average Buy Price</div>
              <div>Total Invested</div>
              <div>LTP</div>
              <div>Profit or Loss</div>
              <div>Percentage</div>
              <div>Now Value</div>
              <div>Action</div>
            </div>

            {portfolio.length === 0 && (
              <div className="table-empty">
                No holdings yet — buy a stock to see it here.
              </div>
            )}

            {portfolio.map((holding, idx) => {
              const stock = allStocks.find((s) => s.id === holding.stockId);
              if (!stock) return null;
              const currentValue = stock.price * holding.shares;
              const invested = holding.avgPrice * holding.shares;
              const gainLoss = currentValue - invested;
              const percent =
                invested > 0 ? (gainLoss / invested) * 100 : 0;
              return (
                <div
key={`${holding.stockId}-${holding.symbol}-${idx}`}
                  className="table-row"
                  style={{ transitionDelay: `${idx * 30}ms` }}
                >
                  <div className="stock-col">
                    <div className="symbol">{stock.symbol}</div>
                    <div className="company">{stock.name}</div>
                  </div>
                  <div>{holding.shares}</div>
                  <div>{formatCurrency(holding.avgPrice)}</div>
                  <div>{formatCurrency(invested)}</div>
                  <div>{formatCurrency(stock.price)}</div>
                  <div className={gainLoss >= 0 ? "green" : "red"}>
                    {gainLoss >= 0 ? "+" : "-"}
                    {formatCurrency(Math.abs(gainLoss))}
                  </div>
                  <div className={gainLoss >= 0 ? "green" : "red"}>
                    {percent.toFixed(2)}%
                  </div>
                  <div>{formatCurrency(currentValue)}</div>
                  <div className="row-actions">
                    <button
                      onClick={() => openModal("buy", stock.id)}
                      className="btn-primary action-equal"
                    >
                      + Buy
                    </button>
                    <button
                      onClick={() => openModal("sell", stock.id)}
                      className="btn-danger action-equal"
                    >
                      Sell
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </main>

      {showModal && selectedStock && (
        <div
          className="modal-backdrop"
          role="dialog"
          aria-modal="true"
          onMouseDown={(e) =>
            e.target === e.currentTarget && closeModal()
          }
        >
          <div className="modal-card" data-anim>
            <div className="modal-head">
              <div>
                <h3>
                  {modalType === "buy" ? "Buy" : "Sell"}{" "}
                  <span className="muted">{selectedStock.symbol}</span>
                </h3>
                <div className="muted small">{selectedStock.name}</div>
              </div>
              <button className="close-x" onClick={closeModal}>
                ✕
              </button>
            </div>

            <div className="modal-body">
              {modalType === "sell" && selectedHolding && (
                <div className="muted">
                  You own: <strong>{selectedHolding.shares}</strong> shares
                </div>
              )}

              <label className="input-label">Quantity</label>
              <input
                className="number-input"
                type="number"
                min="1"
                max={modalType === "sell" ? selectedHolding?.shares : undefined}
                value={quantity}
                onChange={(e) =>
                  setQuantity(e.target.value.replace(/^0+/, ""))
                }
                placeholder="0"
              />

              {quantity && (
                <div className="calc-row">
                  <div className="muted">
                    {modalType === "buy" ? "Total Cost" : "Estimated Revenue"}
                  </div>
                  <div className="calc-value">
                    {formatCurrency(selectedStock.price * Number(quantity))}
                  </div>
                </div>
              )}

              {modalError && (
                <div className="modal-error">{modalError}</div>
              )}
            </div>

            <div className="modal-footer">
              <button className="btn-cancel" onClick={closeModal}>
                Cancel
              </button>
              <button className="btn-submit" onClick={executeTransaction}>
                {modalType === "buy" ? "Buy" : "Sell"}
              </button>
            </div>
          </div>
        </div>
      )}
      {showReco && <RecommendationModal onClose={() => setShowReco(false)} />}

    </div>
  );
}
