// import React, { useMemo, useState, useRef, useEffect } from "react";
// import {
//   ResponsiveContainer,
//   AreaChart,
//   Area,
//   XAxis,
//   YAxis,
//   Tooltip,
//   CartesianGrid,
//   PieChart,
//   Pie,
//   Cell,
//   Sector,
// } from "recharts";
// import {
//   FiTrendingUp,
//   FiTrendingDown,
//   FiPieChart,
//   FiActivity,
//   FiDownload,
// } from "react-icons/fi";
// import { BsWallet2 } from "react-icons/bs";
// import { MdInsights } from "react-icons/md";
// import { motion } from "framer-motion";
// import CountUp from "react-countup";
// import "./Dashboard.css";

// export default function Dashboard({
//   wallet = 0,
//   portfolio = [],
//   transactions = [],
//   allStocks = [],
// }) {
//   console.log("Transactions received in Dashboard:", transactions);
//   const [tf, setTf] = useState("YTD");
//   const [activePieIndex, setActivePieIndex] = useState(-1);
//   const [activePiePayload, setActivePiePayload] = useState(null);
//   const hoverPanelRef = useRef(null);

//   // --- Derived metrics ---
//   const totalInvested = useMemo(
//     () =>
//       portfolio.reduce(
//         (sum, p) => sum + (p.avgPrice ?? 0) * (p.shares ?? 0),
//         0
//       ),
//     [portfolio]
//   );

//   const totalValue = useMemo(
//     () =>
//       portfolio.reduce((sum, p) => {
//         const stock = allStocks.find((s) => s.symbol === p.symbol); // FIXED
//         return stock ? sum + stock.price * (p.shares ?? 0) : sum;
//       }, 0),
//     [portfolio, allStocks]
//   );

//   const totalPL = useMemo(() => totalValue - totalInvested, [
//     totalValue,
//     totalInvested,
//   ]);

//   const holdingsCount = useMemo(
//     () => portfolio.filter((p) => (p.shares ?? 0) > 0).length,
//     [portfolio]
//   );

//   const dayChange = useMemo(() => {
//     return portfolio.reduce((sum, p) => {
//       const stock = allStocks.find((s) => s.symbol === p.symbol); // FIXED
//       if (!stock) return sum;
//       const val = stock.price * (p.shares ?? 0);
//       return sum + (stock.changePercent / 100) * val;
//     }, 0);
//   }, [portfolio, allStocks]);

//   const fmtCurrency = (n) =>
//     (n ?? 0).toLocaleString(undefined, {
//       style: "currency",
//       currency: "USD",
//       maximumFractionDigits: 2,
//     });

//   // --- Chart demo data ---
//   const months = [
//     "Jan","Feb","Mar","Apr","May","Jun",
//     "Jul","Aug","Sep","Oct","Nov","Dec",
//   ];
//   const base = Math.max(totalInvested || 12000, 8000);

//   const portfolioValueSeries = useMemo(() => {
//     const adjustments =
//       tf === "1M"
//         ? [200, 300, 400, 500, 450, 380, 300, 200, 120, 90, 60, 50]
//         : tf === "YTD"
//         ? [-400, -150, 200, 450, 380, 520, 480, 760, 930, 1200, 980, 1400]
//         : [-1200, -900, -400, 0, 200, 520, 680, 880, 1100, 1500, 1600, 2100];
//     return months.map((m, i) => ({
//       month: m,
//       value: Math.max(800, base + adjustments[i]),
//     }));
//   }, [totalInvested, tf]);

//   const plSeries = useMemo(() => {
//     const basePnl =
//       tf === "1M"
//         ? [20, 80, 60, 120, 140, 160, 200, 220, 260, 300, 320, 350]
//         : tf === "YTD"
//         ? [0, 120, -80, 260, 410, 390, 620, 590, 780, 740, 930, 1180]
//         : [-200, -160, -80, 40, 120, 300, 420, 540, 760, 900, 1100, 1800];
//     return months.map((m, i) => ({ month: m, pnl: basePnl[i] }));
//   }, [tf]);

//   // --- sectorSplit ---
//   const sectorSplit = useMemo(() => {
//     if (!portfolio.length) {
//       return [
//         { name: "Tech", value: 40, qty: 0, invested: 0, nowValue: 0 },
//         { name: "Finance", value: 25, qty: 0, invested: 0, nowValue: 0 },
//         { name: "Healthcare", value: 20, qty: 0, invested: 0, nowValue: 0 },
//         { name: "Energy", value: 15, qty: 0, invested: 0, nowValue: 0 },
//       ];
//     }
//     const map = {};
//     portfolio.forEach((p) => {
//       const stock = allStocks.find((s) => s.symbol === p.symbol); // FIXED
//       const sector = stock?.sector ?? "Other";
//       const qty = Number(p.shares ?? 0);
//       const invested = Number((p.avgPrice ?? 0) * qty);
//       const nowValue = Number((stock?.price ?? 0) * qty);
//       map[sector] =
//         map[sector] || { name: sector, value: 0, qty: 0, invested: 0, nowValue: 0 };
//       map[sector].value += nowValue;
//       map[sector].qty += qty;
//       map[sector].invested += invested;
//       map[sector].nowValue += nowValue;
//     });
//     const total = Object.values(map).reduce((a, b) => a + b.value, 0) || 1;
//     return Object.keys(map).map((k) => {
//       const obj = map[k];
//       return {
//         name: obj.name,
//         value: Math.round((obj.value / total) * 100),
//         qty: obj.qty,
//         invested: Math.round(obj.invested),
//         nowValue: Math.round(obj.nowValue),
//         rawValue: obj.value,
//       };
//     });
//   }, [portfolio, allStocks]);

//   const pieColors = [
//     "#2ED3A3",
//     "#7C8CFF",
//     "#54C5FF",
//     "#00E676",
//     "#FDBA8C",
//     "#FF6B6B",
//     "#FFD27F",
//   ];

//   // --- Top performers ---
//   const topPerformers = useMemo(() => {
//     return [...portfolio]
//       .map((p) => {
//         const stock = allStocks.find((s) => s.symbol === p.symbol); // FIXED
//         return {
//           ...p,
//           change: stock?.changePercent ?? 0,
//           price: stock?.price ?? 0,
//         };
//       })
//       .sort((a, b) => (b.change ?? 0) - (a.change ?? 0))
//       .slice(0, 6);
//   }, [portfolio, allStocks]);

//   // --- CSV export ---
//   const exportCSV = (type = "portfolio") => {
//     let rows = [];
//     if (type === "portfolio") {
//       rows.push([
//         "Symbol",
//         "Quantity",
//         "Avg/Invested",
//         "Current Price",
//         "Now Value",
//         "Sector",
//       ]);
//       portfolio.forEach((p) => {
//         const stock = allStocks.find((s) => s.symbol === p.symbol); // FIXED
//         const qty = p.shares ?? 0;
//         const nowVal = (stock?.price ?? 0) * qty;
//         rows.push([
//           p.symbol || "",
//           qty,
//           p.avgPrice ?? "",
//           stock?.price ?? "",
//           nowVal.toFixed(2),
//           stock?.sector ?? "Other",
//         ]);
//       });
//     } else {
//       rows.push(["Symbol", "Side", "Shares", "Amount", "Date"]);
//       transactions.forEach((t) => {
//         rows.push([
//           t.symbol || "",
//           t.type || "",
//           t.shares ?? "",
//           t.amount ?? "",
//           t.date || "",
//         ]);
//       });
//     }
//     const csv = rows.map((r) => r.join(",")).join("\n");
//     const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
//     const url = URL.createObjectURL(blob);
//     const a = document.createElement("a");
//     a.href = url;
//     a.download = `${type}-${new Date().toISOString().slice(0, 10)}.csv`;
//     document.body.appendChild(a);
//     a.click();
//     a.remove();
//     URL.revokeObjectURL(url);
//   };

//   // ... rest of your component remains same (charts, pie, cards, etc.)


//   // --- Pie hover ---
//   function renderActiveShape(props) {
//     const {
//       cx,
//       cy,
//       midAngle,
//       innerRadius,
//       outerRadius,
//       startAngle,
//       endAngle,
//       fill,
//       payload,
//       percent,
//     } = props;
//     const RAD = Math.PI / 180;
//     const sin = Math.sin(-RAD * midAngle);
//     const cos = Math.cos(-RAD * midAngle);
//     const sx = cx + (outerRadius + 8) * cos;
//     const sy = cy + (outerRadius + 8) * sin;
//     const mx = cx + (outerRadius + 28) * cos;
//     const my = cy + (outerRadius + 28) * sin;
    
//     return (
//       <g>
//         <Sector
//           cx={cx}
//           cy={cy}
//           innerRadius={innerRadius}
//           outerRadius={outerRadius + 8}
//           startAngle={startAngle}
//           endAngle={endAngle}
//           fill={fill}
//           stroke="rgba(255,255,255,0.06)"
//         />
//         <path d={`M${sx},${sy}L${mx},${my}`} stroke={fill} fill="none" />
//         <circle cx={mx} cy={my} r={6} fill={fill} />
//         <text
//           x={mx + (cos > 0 ? 10 : -10)}
//           y={my}
//           textAnchor={cos > 0 ? "start" : "end"}
//           fill="#E6EEF6"
//           fontWeight={800}
//         >
//           {payload.name}
//         </text>
//         <text
//           x={mx + (cos > 0 ? 10 : -10)}
//           y={my + 18}
//           textAnchor={cos > 0 ? "start" : "end"}
//           fill="#9fb0bf"
//           fontSize={12}
//         >
//           {payload.value}% • {(percent * 100).toFixed(1)}%
//         </text>
//       </g>
//     );
//   }

//   const onPieEnter = (_, index) => {
//     setActivePieIndex(index);
//     setActivePiePayload(sectorSplit[index] || null);
//   };
//   const onPieLeave = () => {
//     setActivePieIndex(-1);
//     setActivePiePayload(null);
//   };
//   const [hoverPos, setHoverPos] = useState({ x: 0, y: 0 });
//   const onPieMouseMove = (e) => {
//     const rect = e.currentTarget.getBoundingClientRect();
//     setHoverPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
//   };

//   // --- Sparkline mini chart ---
//   const Sparkline = ({ values = [], color = "#2ED3A3", height = 28 }) => {
//     const w = Math.max(values.length * 6, 60);
//     const max = Math.max(...values, 1);
//     const points = values
//       .map(
//         (v, i) =>
//           `${(i / (values.length - 1)) * w},${height - (v / max) * height}`
//       )
//       .join(" ");
//     return (
//       <svg
//         className="sparkline"
//         width={w}
//         height={height}
//         viewBox={`0 0 ${w} ${height}`}
//         preserveAspectRatio="none"
//       >
//         <polyline
//           fill="none"
//           stroke={color}
//           strokeWidth="2"
//           points={points}
//           strokeLinecap="round"
//           strokeLinejoin="round"
//         />
//       </svg>
//     );
//   };
//   // --- Sparkline data generator ---
//   const sparkFor = (symbol, baseVal = 1, seed = 5) => {
//     let s = 0;
//     for (let i = 0; i < symbol.length; i++) {
//       s = (s * 31 + symbol.charCodeAt(i)) % 9973;
//     }
//     return Array.from({ length: 12 }, (_, i) => {
//       const jitter = ((s % (i + 7)) - 3) * 0.02;
//       s = (s * 73 + i) % 9973;
//       return Math.max(0, baseVal * (1 + jitter + Math.sin(i + s) * 0.02));
//     });
//   };

//   return (
//     <motion.div
//       initial={{ opacity: 0, y: 8 }}
//       animate={{ opacity: 1, y: 0 }}
//       className="dash page-bg"
//     >
//       {/* Header */}
//       <div className="dash__header">
//         <div>
//           <h1 className="dash__title">Dashboard</h1>
//           <p className="dash__subtitle">
//             Your trading overview and performance metrics
//           </p>
//         </div>
//         <div className="header-tools">
//           <div className="wallet-pill">
//             <BsWallet2 />
//             <span>
//               Wallet: <strong>{fmtCurrency(wallet)}</strong>
//             </span>
//           </div>
//           <button
//             className="export-btn"
//             onClick={() => exportCSV("portfolio")}
//             title="Export portfolio CSV"
//           >
//             <FiDownload /> Export CSV
//           </button>
//         </div>
//       </div>

//       {/* Metric Cards */}
//       <div className="grid grid--4">
//         <MetricCard
//           icon={<BsWallet2 />}
//           label="Portfolio Value"
//           value={
//             <CountUp
//               end={totalValue || 0}
//               duration={1.2}
//               formattingFn={fmtCurrency}
//             />
//           }
//           sub={`Total invested: ${fmtCurrency(totalInvested)}`}
//         />
//         <MetricCard
//           icon={<MdInsights />}
//           label="Total P&L"
//           value={
//             <CountUp
//               end={totalPL || 0}
//               duration={1.2}
//               formattingFn={fmtCurrency}
//             />
//           }
//           sub={`${((totalPL / (totalInvested || 1)) * 100).toFixed(2)}% return`}
//           tone={totalPL >= 0 ? "good" : "bad"}
//         />
//         <MetricCard
//           icon={<FiPieChart />}
//           label="Holdings"
//           value={<div className="metric__value">{holdingsCount}</div>}
//           sub="Active positions"
//         />
//         <MetricCard
//           icon={<FiActivity />}
//           label="Day Change"
//           value={
//             <div className="metric__value">
//               {dayChange >= 0 ? "+" : ""}
//               {fmtCurrency(dayChange)}
//             </div>
//           }
//           sub={`${(
//             (dayChange / (totalValue || 1)) *
//             100
//           ).toFixed(2)}% today`}
//           tone={dayChange >= 0 ? "good" : "bad"}
//         />
//       </div>

//       {/* Timeframe controls */}
//       <div className="chart-controls">
//         <div className="tf-buttons">
//           {["1M", "YTD", "1Y"].map((t) => (
//             <button
//               key={t}
//               className={`tf-btn ${tf === t ? "active" : ""}`}
//               onClick={() => setTf(t)}
//             >
//               {t}
//             </button>
//           ))}
//         </div>
//       </div>

//       {/* Charts */}
//       <div className="grid grid--2">
//         <ChartCard title="Portfolio Value" tag="+12.4% YTD" tagTone="good">
//           <ResponsiveContainer width="100%" height={320}>
//             <AreaChart data={portfolioValueSeries}>
//               <CartesianGrid stroke="rgba(255,255,255,0.03)" vertical={false} />
//               <XAxis dataKey="month" tick={{ fill: "#AAB8C7" }} />
//               <YAxis tick={{ fill: "#AAB8C7" }} />
//               <Tooltip
//                 contentStyle={{
//                   background: "#0E1722",
//                   border: "1px solid rgba(255,255,255,0.05)",
//                 }}
//                 formatter={(v) => fmtCurrency(v)}
//               />
//               <Area
//                 type="monotone"
//                 dataKey="value"
//                 stroke="#26E07F"
//                 fill="rgba(38,224,127,0.25)"
//               />
//             </AreaChart>
//           </ResponsiveContainer>
//         </ChartCard>

//         <ChartCard
//           title="Profit & Loss"
//           tag={`+${fmtCurrency(plSeries.reduce((s, p) => s + p.pnl, 0))}`}
//           tagTone="good"
//         >
//           <ResponsiveContainer width="100%" height={320}>
//             <AreaChart data={plSeries}>
//               <CartesianGrid stroke="rgba(255,255,255,0.03)" vertical={false} />
//               <XAxis dataKey="month" tick={{ fill: "#AAB8C7" }} />
//               <YAxis tick={{ fill: "#AAB8C7" }} />
//               <Tooltip
//                 contentStyle={{
//                   background: "#0E1722",
//                   border: "1px solid rgba(255,255,255,0.05)",
//                 }}
//                 formatter={(v) => fmtCurrency(v)}
//               />
//               <Area
//                 type="monotone"
//                 dataKey="pnl"
//                 stroke="#7C8CFF"
//                 fill="rgba(124,140,255,0.25)"
//               />
//             </AreaChart>
//           </ResponsiveContainer>
//         </ChartCard>
//       </div>

//       {/* Lower row */}
//       <div className="grid grid--3">
//         {/* Top performers */}
//         <Card
//           title="Top Performers"
//           actions={[
//             { label: "Export CSV", onClick: () => exportCSV("portfolio") },
//           ]}
//         >
//           {topPerformers.length === 0 ? (
//             <div className="empty">
//               <div className="empty__icon">📈</div>
//               <div>No holdings to display</div>
//             </div>
//           ) : (
//             <ul className="list list--performers">
//               {topPerformers.map((p, idx) => {
//                 const baseVal = p.price || 1;
//                 const spark = sparkFor(p.symbol || `S${idx}`, baseVal);
                
//                 console.log("Transactions received in Dashboard:", transactions);

                
//                 return (
//                  <li key={`${p.symbol}-${idx}`} className="list-row performer-row">
//                     <div className="performer-left">
//                       <div className="rank">#{idx + 1}</div>
//                       <div>
//                         <div className="perform-symbol">{p.symbol}</div>
//                         <div className="small">
//                           ${(p.price ?? 0).toFixed(2)}
//                         </div>
//                       </div>
//                     </div>
//                     <div className="perform-right">
//                       <div
//                         className={`trend ${p.change >= 0 ? "pos" : "neg"}`}
//                       >
//                         {p.change >= 0 ? <FiTrendingUp /> : <FiTrendingDown />}
//                         <strong>
//                           {p.change ? `${p.change.toFixed(2)}%` : "0.00%"}
//                         </strong>
//                       </div>
//                       <div className="spark-wrap" aria-hidden>
//                         <Sparkline
//                           values={spark}
//                           color={p.change >= 0 ? "#2ED3A3" : "#FF6B6B"}
//                         />
//                       </div>
//                     </div>
//                   </li>
//                 );
//               })}
//             </ul>
//           )}
//         </Card>

//         {/* Investment split */}
//         <Card title="Investment Split">
//           <div className="pie-wrapper">
//             <div className="pie-3d-viewport" onMouseMove={onPieMouseMove}>
//               <ResponsiveContainer width="100%" height={260}>
//                 <PieChart>
//                   <Pie
//                     data={sectorSplit}
//                     dataKey="value"
//                     nameKey="name"
//                     cx="50%"
//                     cy="50%"
//                     innerRadius={58}
//                     outerRadius={110}
//                     paddingAngle={4}
//                     startAngle={90}
//                     endAngle={-270}
//                     activeIndex={activePieIndex}
//                     activeShape={renderActiveShape}
//                     onMouseEnter={onPieEnter}
//                     onMouseLeave={onPieLeave}
//                   >
//                     {sectorSplit.map((entry, index) => (
//                       <Cell
//                         key={`c-${index}`}
//                         fill={pieColors[index % pieColors.length]}
//                       />
//                     ))}
//                   </Pie>
//                 </PieChart>
//               </ResponsiveContainer>

//               {/* Hover panel */}
//               <motion.div
//                 className="pie-hover-panel"
//                 ref={hoverPanelRef}
//                 animate={{
//                   opacity: activePiePayload ? 1 : 0,
//                   y: activePiePayload ? 0 : 8,
//                 }}
//                 initial={{ opacity: 0 }}
//                 transition={{ duration: 0.18 }}
//                 style={{
//                   left: hoverPos.x + 8,
//                   top: hoverPos.y + 8,
//                   pointerEvents: activePiePayload ? "auto" : "none",
//                 }}
//               >
//                 {activePiePayload ? (
//                   <>
//                     <div className="hover-title">{activePiePayload.name}</div>
//                     <div className="hover-row">
//                       <div className="hover-label">Allocation</div>
//                       <div className="hover-val">
//                         {activePiePayload.value}%
//                       </div>
//                     </div>
//                     <div className="hover-row">
//                       <div className="hover-label">Quantity</div>
//                       <div className="hover-val">
//                         {activePiePayload.qty ?? 0}
//                       </div>
//                     </div>
//                     <div className="hover-row">
//                       <div className="hover-label">Invested</div>
//                       <div className="hover-val">
//                         {fmtCurrency(activePiePayload.invested ?? 0)}
//                       </div>
//                     </div>
//                     <div className="hover-row">
//                       <div className="hover-label">Now Value</div>
//                       <div className="hover-val">
//                         {fmtCurrency(
//                           activePiePayload.nowValue ??
//                             activePiePayload.rawValue ??
//                             0
//                         )}
//                       </div>
//                     </div>
//                   </>
//                 ) : (
//                   <div className="hover-empty">Hover a slice for details</div>
//                 )}
//               </motion.div>
//             </div>

//             <div className="legend legend-grid">
//               {sectorSplit.map((s, i) => (
//                <div key={`${s.name}-${i}`} className="legend__row">

//                   <span
//                     className="dot"
//                     style={{ background: pieColors[i % pieColors.length] }}
//                   />
//                   <div className="legend__label">
//                     <div className="legend__name">{s.name}</div>
//                     <div className="legend__val">{s.value}%</div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </div>
//         </Card>

        

//         {/* Recent transactions */}
//         <Card
//           title="Recent Transactions"
//           actions={[
//             { label: "Export CSV", onClick: () => exportCSV("transactions") },
//           ]}
//         >
//           {transactions.length === 0 ? (
//             <div className="empty">
//               <div className="empty__icon">🧾</div>
//               <div>No recent activity</div>
//             </div>
//           ) : (
//             <ul className="list list--tx">
//               {transactions.slice(0, 8).map((t, idx) => (
//                  <li key={`${t.symbol}-${t.date}-${idx}`} className="tx-row">
//                   <div className="tx-left">
//                     <div className={`pill ${t.type === "BUY" ? "buy" : "sell"}`}>
//                       {t.type}
//                     </div>
//                     <div>
//                       <div className="tx-symbol">{t.symbol}</div>
//                       <div className="small">
//                         Qty: {t.shares} • {t.date}
//                       </div>
//                     </div>
//                   </div>
//                   <div className="tx-right">
//                     <div className="tx-amt">{fmtCurrency(t.amount)}</div>
//                   </div>
//                 </li>
//               ))}
//             </ul>
//           )}
//         </Card>
//       </div>
//     </motion.div>
//   );


// /* --- Small UI components --- */
// function MetricCard({ icon, label, value, sub, tone = "neutral" }) {
//   return (
//     <motion.div
//       initial={{ opacity: 0, y: 8 }}
//       animate={{ opacity: 1, y: 0 }}
//       transition={{ duration: 0.45 }}
//       className={`metric ${tone} hover-lift`}
//     >
//       <div className="metric__icon">{icon}</div>
//       <div className="metric__body">
//         <div className="metric__label">{label}</div>
//         <div className="metric__value">{value}</div>
//         {sub && <div className="metric__sub">{sub}</div>}
//       </div>
//     </motion.div>
//   );
// }

// function ChartCard({ title, tag, tagTone = "neutral", children }) {
//   return (
//     <motion.div
//       initial={{ opacity: 0, y: 10 }}
//       animate={{ opacity: 1, y: 0 }}
//       transition={{ duration: 0.5 }}
//       className="chart-card hover-lift"
//     >
//       <div className="card__head">
//         <h3>{title}</h3>
//         {tag && <span className={`tag ${tagTone}`}>{tag}</span>}
//       </div>
//       <div className="card__body">{children}</div>
//     </motion.div>
//   );
// }

// function Card({ title, children, actions = [] }) {
//   return (
//     <motion.div
//       initial={{ opacity: 0, y: 10 }}
//       animate={{ opacity: 1, y: 0 }}
//       transition={{ duration: 0.5 }}
//       className="chart-card hover-lift"
//     >
//       <div className="card__head" style={{ marginBottom: 12 }}>
//         <h3>{title}</h3>
//         <div style={{ display: "flex", gap: 8 }}>
//           {actions.map((a, i) => (
//             <button key={i} className="ghost-btn" onClick={a.onClick}>
//               {a.label}
//             </button>
//           ))}
//         </div>
//       </div>
//       <div className="card__body">{children}</div>
//     </motion.div>
//   );
// }
// }


import React, { useMemo, useState, useRef } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Sector,
} from "recharts";
import {
  FiTrendingUp,
  FiTrendingDown,
  FiPieChart,
  FiActivity,
  FiDownload,
} from "react-icons/fi";
import { BsWallet2 } from "react-icons/bs";
import { MdInsights } from "react-icons/md";
import { motion } from "framer-motion";
import CountUp from "react-countup";
import "./Dashboard.css";

export default function Dashboard({
  wallet = 0,
  portfolio = [],
  transactions = [],
  allStocks = [],
}) {
  console.log("Transactions received in Dashboard:", transactions);
  const [tf, setTf] = useState("YTD");
  const [activePieIndex, setActivePieIndex] = useState(-1);
  const [activePiePayload, setActivePiePayload] = useState(null);
  const hoverPanelRef = useRef(null);

  // --- Derived metrics ---
  const totalInvested = useMemo(
    () =>
      portfolio.reduce(
        (sum, p) => sum + (p.avgPrice ?? 0) * (p.shares ?? 0),
        0
      ),
    [portfolio]
  );

  const totalValue = useMemo(
    () =>
      portfolio.reduce((sum, p) => {
        const stock = allStocks.find((s) => s.symbol === p.symbol);
        return stock ? sum + stock.price * (p.shares ?? 0) : sum;
      }, 0),
    [portfolio, allStocks]
  );

  const totalPL = useMemo(() => totalValue - totalInvested, [
    totalValue,
    totalInvested,
  ]);

  const holdingsCount = useMemo(
    () => portfolio.filter((p) => (p.shares ?? 0) > 0).length,
    [portfolio]
  );

  const dayChange = useMemo(() => {
    return portfolio.reduce((sum, p) => {
      const stock = allStocks.find((s) => s.symbol === p.symbol);
      if (!stock) return sum;
      const val = stock.price * (p.shares ?? 0);
      return sum + (stock.changePercent / 100) * val;
    }, 0);
  }, [portfolio, allStocks]);

  const fmtCurrency = (n) =>
    (n ?? 0).toLocaleString(undefined, {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 2,
    });

  // --- Chart demo data ---
  const months = [
    "Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec",
  ];
  const base = Math.max(totalInvested || 12000, 8000);

  const portfolioValueSeries = useMemo(() => {
    const adjustments =
      tf === "1M"
        ? [200, 300, 400, 500, 450, 380, 300, 200, 120, 90, 60, 50]
        : tf === "YTD"
        ? [-400, -150, 200, 450, 380, 520, 480, 760, 930, 1200, 980, 1400]
        : [-1200, -900, -400, 0, 200, 520, 680, 880, 1100, 1500, 1600, 2100];
    return months.map((m, i) => ({
      month: m,
      value: Math.max(800, base + adjustments[i]),
    }));
  }, [totalInvested, tf]);

  const plSeries = useMemo(() => {
    const basePnl =
      tf === "1M"
        ? [20, 80, 60, 120, 140, 160, 200, 220, 260, 300, 320, 350]
        : tf === "YTD"
        ? [0, 120, -80, 260, 410, 390, 620, 590, 780, 740, 930, 1180]
        : [-200, -160, -80, 40, 120, 300, 420, 540, 760, 900, 1100, 1800];
    return months.map((m, i) => ({ month: m, pnl: basePnl[i] }));
  }, [tf]);

  // --- sectorSplit ---
  const sectorSplit = useMemo(() => {
    if (!portfolio.length) {
      return [
        { name: "Tech", value: 40, qty: 0, invested: 0, nowValue: 0 },
        { name: "Finance", value: 25, qty: 0, invested: 0, nowValue: 0 },
        { name: "Healthcare", value: 20, qty: 0, invested: 0, nowValue: 0 },
        { name: "Energy", value: 15, qty: 0, invested: 0, nowValue: 0 },
      ];
    }
    const map = {};
    portfolio.forEach((p) => {
      const stock = allStocks.find((s) => s.symbol === p.symbol);
      const sector = stock?.sector ?? "Other";
      const qty = Number(p.shares ?? 0);
      const invested = Number((p.avgPrice ?? 0) * qty);
      const nowValue = Number((stock?.price ?? 0) * qty);
      map[sector] =
        map[sector] || { name: sector, value: 0, qty: 0, invested: 0, nowValue: 0 };
      map[sector].value += nowValue;
      map[sector].qty += qty;
      map[sector].invested += invested;
      map[sector].nowValue += nowValue;
    });
    const total = Object.values(map).reduce((a, b) => a + b.value, 0) || 1;
    return Object.keys(map).map((k) => {
      const obj = map[k];
      return {
        name: obj.name,
        value: Math.round((obj.value / total) * 100),
        qty: obj.qty,
        invested: Math.round(obj.invested),
        nowValue: Math.round(obj.nowValue),
        rawValue: obj.value,
      };
    });
  }, [portfolio, allStocks]);

  console.log("sectorSplit", sectorSplit); // 🔍 debug pie data

  const pieColors = [
    "#2ED3A3",
    "#7C8CFF",
    "#54C5FF",
    "#00E676",
    "#FDBA8C",
    "#FF6B6B",
    "#FFD27F",
  ];

  // --- Top performers ---
  const topPerformers = useMemo(() => {
    return [...portfolio]
      .map((p) => {
        const stock = allStocks.find((s) => s.symbol === p.symbol);
        return {
          ...p,
          change: stock?.changePercent ?? 0,
          price: stock?.price ?? 0,
        };
      })
      .sort((a, b) => (b.change ?? 0) - (a.change ?? 0))
      .slice(0, 6);
  }, [portfolio, allStocks]);

  // --- CSV export ---
  const exportCSV = (type = "portfolio") => {
    let rows = [];
    if (type === "portfolio") {
      rows.push([
        "Symbol","Quantity","Avg/Invested","Current Price","Now Value","Sector",
      ]);
      portfolio.forEach((p) => {
        const stock = allStocks.find((s) => s.symbol === p.symbol);
        const qty = p.shares ?? 0;
        const nowVal = (stock?.price ?? 0) * qty;
        rows.push([
          p.symbol || "",
          qty,
          p.avgPrice ?? "",
          stock?.price ?? "",
          nowVal.toFixed(2),
          stock?.sector ?? "Other",
        ]);
      });
    } else {
      rows.push(["Symbol", "Side", "Shares", "Amount", "Date"]);
      transactions.forEach((t) => {
        rows.push([
          t.symbol || "",
          t.type || "",
          t.shares ?? "",
          t.amount ?? "",
          t.date || "",
        ]);
      });
    }
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${type}-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  // --- Pie hover ---
  function renderActiveShape(props) {
    const {
      cx, cy, midAngle, innerRadius, outerRadius,
      startAngle, endAngle, fill, payload, percent,
    } = props;
    const RAD = Math.PI / 180;
    const sin = Math.sin(-RAD * midAngle);
    const cos = Math.cos(-RAD * midAngle);
    const sx = cx + (outerRadius + 8) * cos;
    const sy = cy + (outerRadius + 8) * sin;
    const mx = cx + (outerRadius + 28) * cos;
    const my = cy + (outerRadius + 28) * sin;
    
    return (
      <g>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={outerRadius + 8}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={fill}
          stroke="rgba(255,255,255,0.06)"
        />
        <path d={`M${sx},${sy}L${mx},${my}`} stroke={fill} fill="none" />
        <circle cx={mx} cy={my} r={6} fill={fill} />
        <text
          x={mx + (cos > 0 ? 10 : -10)}
          y={my}
          textAnchor={cos > 0 ? "start" : "end"}
          fill="#E6EEF6"
          fontWeight={800}
        >
          {payload.name}
        </text>
        <text
          x={mx + (cos > 0 ? 10 : -10)}
          y={my + 18}
          textAnchor={cos > 0 ? "start" : "end"}
          fill="#9fb0bf"
          fontSize={12}
        >
          {payload.value}% • {(percent * 100).toFixed(1)}%
        </text>
      </g>
    );
  }

  const onPieEnter = (_, index) => {
    setActivePieIndex(index);
    setActivePiePayload(sectorSplit[index] || null);
  };
  const onPieLeave = () => {
    setActivePieIndex(-1);
    setActivePiePayload(null);
  };
  const [hoverPos, setHoverPos] = useState({ x: 0, y: 0 });
  const onPieMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setHoverPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  // --- Sparkline mini chart ---
  const Sparkline = ({ values = [], color = "#2ED3A3", height = 28 }) => {
    const w = Math.max(values.length * 6, 60);
    const max = Math.max(...values, 1);
    const points = values
      .map(
        (v, i) =>
          `${(i / (values.length - 1)) * w},${height - (v / max) * height}`
      )
      .join(" ");
    return (
      <svg
        className="sparkline"
        width={w}
        height={height}
        viewBox={`0 0 ${w} ${height}`}
        preserveAspectRatio="none"
      >
        <polyline
          fill="none"
          stroke={color}
          strokeWidth="2"
          points={points}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  };

  // --- Sparkline data generator ---
  const sparkFor = (symbol, baseVal = 1, seed = 5) => {
    let s = 0;
    for (let i = 0; i < symbol.length; i++) {
      s = (s * 31 + symbol.charCodeAt(i)) % 9973;
    }
    return Array.from({ length: 12 }, (_, i) => {
      const jitter = ((s % (i + 7)) - 3) * 0.02;
      s = (s * 73 + i) % 9973;
      return Math.max(0, baseVal * (1 + jitter + Math.sin(i + s) * 0.02));
    });
  };

  // --- UI ---
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="dash page-bg"
    >
      {/* Header */}
      <div className="dash__header">
        <div>
          <h1 className="dash__title">Dashboard</h1>
          <p className="dash__subtitle">
            Your trading overview and performance metrics
          </p>
        </div>
        <div className="header-tools">
          <div className="wallet-pill">
            <BsWallet2 />
            <span>
              Wallet: <strong>{fmtCurrency(wallet)}</strong>
            </span>
          </div>
          <button
            className="export-btn"
            onClick={() => exportCSV("portfolio")}
            title="Export portfolio CSV"
          >
            <FiDownload /> Export CSV
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid--4">
        <MetricCard
          icon={<BsWallet2 />}
          label="Portfolio Value"
          value={
            <CountUp
              end={totalValue || 0}
              duration={1.2}
              formattingFn={fmtCurrency}
            />
          }
          sub={`Total invested: ${fmtCurrency(totalInvested)}`}
        />
        <MetricCard
          icon={<MdInsights />}
          label="Total P&L"
          value={
            <CountUp
              end={totalPL || 0}
              duration={1.2}
              formattingFn={fmtCurrency}
            />
          }
          sub={`${((totalPL / (totalInvested || 1)) * 100).toFixed(2)}% return`}
          tone={totalPL >= 0 ? "good" : "bad"}
        />
        <MetricCard
          icon={<FiPieChart />}
          label="Holdings"
          value={<div className="metric__value">{holdingsCount}</div>}
          sub="Active positions"
        />
        <MetricCard
          icon={<FiActivity />}
          label="Day Change"
          value={
            <div className="metric__value">
              {dayChange >= 0 ? "+" : ""}
              {fmtCurrency(dayChange)}
            </div>
          }
          sub={`${(
            (dayChange / (totalValue || 1)) *
            100
          ).toFixed(2)}% today`}
          tone={dayChange >= 0 ? "good" : "bad"}
        />
      </div>

      {/* Timeframe controls */}
      <div className="chart-controls">
        <div className="tf-buttons">
          {["1M", "YTD", "1Y"].map((t) => (
            <button
              key={t}
              className={`tf-btn ${tf === t ? "active" : ""}`}
              onClick={() => setTf(t)}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid--2">
        <ChartCard title="Portfolio Value" tag="+12.4% YTD" tagTone="good">
          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={portfolioValueSeries}>
              <CartesianGrid stroke="rgba(255,255,255,0.03)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#AAB8C7" }} />
              <YAxis tick={{ fill: "#AAB8C7" }} />
              <Tooltip
                contentStyle={{
                  background: "#0E1722",
                  border: "1px solid rgba(255,255,255,0.05)",
                }}
                formatter={(v) => fmtCurrency(v)}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke="#26E07F"
                fill="rgba(38,224,127,0.25)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="Profit & Loss"
          tag={`+${fmtCurrency(plSeries.reduce((s, p) => s + p.pnl, 0))}`}
          tagTone="good"
        >
          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={plSeries}>
              <CartesianGrid stroke="rgba(255,255,255,0.03)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#AAB8C7" }} />
              <YAxis tick={{ fill: "#AAB8C7" }} />
              <Tooltip
                contentStyle={{
                  background: "#0E1722",
                  border: "1px solid rgba(255,255,255,0.05)",
                }}
                formatter={(v) => fmtCurrency(v)}
              />
              <Area
                type="monotone"
                dataKey="pnl"
                stroke="#7C8CFF"
                fill="rgba(124,140,255,0.25)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Lower row */}
      <div className="grid grid--3">
        {/* Top performers */}
        <Card
          title="Top Performers"
          actions={[{ label: "Export CSV", onClick: () => exportCSV("portfolio") }]}
        >
          {topPerformers.length === 0 ? (
            <div className="empty">
              <div className="empty__icon">📈</div>
              <div>No holdings to display</div>
            </div>
          ) : (
            <ul className="list list--performers">
              {topPerformers.map((p, idx) => {
                const baseVal = p.price || 1;
                const spark = sparkFor(p.symbol || `S${idx}`, baseVal);
                return (
                  <li key={`${p.symbol}-${idx}`} className="list-row performer-row">
                    <div className="performer-left">
                      <div className="rank">#{idx + 1}</div>
                      <div>
                        <div className="perform-symbol">{p.symbol}</div>
                        <div className="small">₹{(p.price ?? 0).toFixed(2)}</div>
                      </div>
                    </div>
                    <div className="perform-right">
                      <div className={`trend ${p.change >= 0 ? "pos" : "neg"}`}>
                        {p.change >= 0 ? <FiTrendingUp /> : <FiTrendingDown />}
                        <strong>
                          {p.change ? `${p.change.toFixed(2)}%` : "0.00%"}
                        </strong>
                      </div>
                      <div className="spark-wrap" aria-hidden>
                        <Sparkline
                          values={spark}
                          color={p.change >= 0 ? "#2ED3A3" : "#FF6B6B"}
                        />
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        {/* Investment split */}
        <Card title="Investment Split">
          <div className="pie-wrapper">
            <div className="pie-3d-viewport" onMouseMove={onPieMouseMove}>
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={sectorSplit}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={58}
                    outerRadius={110}
                    paddingAngle={4}
                    startAngle={90}
                    endAngle={-270}
                    activeIndex={activePieIndex}
                    activeShape={renderActiveShape}
                    onMouseEnter={onPieEnter}
                    onMouseLeave={onPieLeave}
                  >
                    {sectorSplit.map((entry, index) => (
                      <Cell
                        key={`c-${index}`}
                        fill={pieColors[index % pieColors.length]}
                      />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>

              {/* Hover panel */}
              <motion.div
                className="pie-hover-panel"
                ref={hoverPanelRef}
                animate={{
                  opacity: activePiePayload ? 1 : 0,
                  y: activePiePayload ? 0 : 8,
                }}
                initial={{ opacity: 0 }}
                transition={{ duration: 0.18 }}
                style={{
                  left: hoverPos.x + 8,
                  top: hoverPos.y + 8,
                  pointerEvents: activePiePayload ? "auto" : "none",
                }}
              >
                {activePiePayload ? (
                  <>
                    <div className="hover-title">{activePiePayload.name}</div>
                    <div className="hover-row">
                      <div className="hover-label">Allocation</div>
                      <div className="hover-val">{activePiePayload.value}%</div>
                    </div>
                    <div className="hover-row">
                      <div className="hover-label">Quantity</div>
                      <div className="hover-val">{activePiePayload.qty ?? 0}</div>
                    </div>
                    <div className="hover-row">
                      <div className="hover-label">Invested</div>
                      <div className="hover-val">
                        {fmtCurrency(activePiePayload.invested ?? 0)}
                      </div>
                    </div>
                    <div className="hover-row">
                      <div className="hover-label">Now Value</div>
                      <div className="hover-val">
                        {fmtCurrency(
                          activePiePayload.nowValue ??
                            activePiePayload.rawValue ??
                            0
                        )}
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="hover-empty">Hover a slice for details</div>
                )}
              </motion.div>
            </div>

            <div className="legend legend-grid">
              {sectorSplit.map((s, i) => (
                <div key={`${s.name}-${i}`} className="legend__row">
                  <span
                    className="dot"
                    style={{ background: pieColors[i % pieColors.length] }}
                  />
                  <div className="legend__label">
                    <div className="legend__name">{s.name}</div>
                    <div className="legend__val">{s.value}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Recent transactions */}
        <Card
          title="Recent Transactions"
          actions={[{ label: "Export CSV", onClick: () => exportCSV("transactions") }]}
        >
          {transactions.length === 0 ? (
            <div className="empty">
              <div className="empty__icon">🧾</div>
              <div>No recent activity</div>
            </div>
          ) : (
            <ul className="list list--tx">
              {transactions.slice(0, 8).map((t, idx) => (
                <li key={`${t.symbol}-${t.date}-${idx}`} className="tx-row">
                  <div className="tx-left">
                    <div className={`pill ${t.type === "BUY" ? "buy" : "sell"}`}>
                      {t.type}
                    </div>
                    <div>
                      <div className="tx-symbol">{t.symbol}</div>
                      <div className="small">
                        Qty: {t.shares} • {t.date}
                      </div>
                    </div>
                  </div>
                  <div className="tx-right">
                    <div className="tx-amt">{fmtCurrency(t.amount)}</div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </motion.div>
  );
}

/* --- Small UI components --- */
function MetricCard({ icon, label, value, sub, tone = "neutral" }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className={`metric ${tone} hover-lift`}
    >
      <div className="metric__icon">{icon}</div>
      <div className="metric__body">
        <div className="metric__label">{label}</div>
        <div className="metric__value">{value}</div>
        {sub && <div className="metric__sub">{sub}</div>}
      </div>
    </motion.div>
  );
}

function ChartCard({ title, tag, tagTone = "neutral", children }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="chart-card hover-lift"
    >
      <div className="card__head">
        <h3>{title}</h3>
        {tag && <span className={`tag ${tagTone}`}>{tag}</span>}
      </div>
      <div className="card__body">{children}</div>
    </motion.div>
  );
}

function Card({ title, children, actions = [] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="chart-card hover-lift"
    >
      <div className="card__head" style={{ marginBottom: 12 }}>
        <h3>{title}</h3>
        <div style={{ display: "flex", gap: 8 }}>
          {actions.map((a, i) => (
            <button key={i} className="ghost-btn" onClick={a.onClick}>
              {a.label}
            </button>
          ))}
        </div>
      </div>
      <div className="card__body">{children}</div>
    </motion.div>
  );
}
