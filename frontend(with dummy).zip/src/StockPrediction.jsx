import React, { useState } from "react";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { motion } from "framer-motion";
import { BarChart3, Activity, Cpu } from "lucide-react";

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend, Filler);

export default function StockPrediction() {
  const [symbol, setSymbol] = useState("");
  const [hasResult, setHasResult] = useState(false);
  const [logs, setLogs] = useState("");

  const [predData, setPredData] = useState(null);
  const [maData, setMaData] = useState(null);
  const [ma100Data, setMa100Data] = useState(null);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: { color: "#cbd5e1", boxWidth: 14 },
      },
      tooltip: { intersect: false, mode: "index" },
    },
    elements: { point: { radius: 0 } },
    scales: {
      x: {
        type: "category",
        grid: { color: "rgba(148,163,184,0.2)" },
        ticks: { color: "#94a3b8", maxRotation: 0 },
      },
      y: {
        type: "linear",
        grid: { color: "rgba(148,163,184,0.2)" },
        ticks: { color: "#94a3b8" },
      },
    },
  };

  const genSeries = (n, start = 55, drift = 0.02, noise = 0.35) => {
    const out = [];
    let v = start;
    for (let i = 0; i < n; i++) {
      v += drift + (Math.random() - 0.5) * noise;
      out.push(+v.toFixed(2));
    }
    return out;
  };
  const sma = (arr, win) => {
    const res = Array(arr.length).fill(null);
    let sum = 0;
    for (let i = 0; i < arr.length; i++) {
      sum += arr[i];
      if (i >= win) sum -= arr[i - win];
      if (i >= win - 1) res[i] = +(sum / win).toFixed(2);
    }
    return res;
  };

  const handlePredict = () => {
    const N = 180;
    const labels = Array.from({ length: N }, (_, i) =>
      i % 20 === 0 ? `2018` : i % 20 === 10 ? `2019` : ""
    );

    const actual = genSeries(N, 55, 0.015, 0.35);
    const ma100 = sma(actual, 20);
    const ma200 = sma(actual, 40);
    const predicted = actual.map((v, i) =>
      i < N - 35 ? null : +((ma100[i] ?? v) + (Math.random() - 0.5) * 0.6).toFixed(2)
    );

    setPredData({
      labels,
      datasets: [
        {
          label: "Actual Stock Price",
          data: actual,
          borderColor: "#60a5fa",
          tension: 0.25,
        },
        {
          label: "Predicted Stock Price",
          data: predicted,
          borderColor: "#ef4444",
          borderDash: [6, 6],
          tension: 0.25,
        },
      ],
    });

    setMaData({
      labels,
      datasets: [
        { label: "Actual Price", data: actual, borderColor: "#60a5fa", tension: 0.25 },
        { label: "100-Day MA", data: ma100, borderColor: "#f59e0b", tension: 0.25 },
        { label: "200-Day MA", data: ma200, borderColor: "#22c55e", tension: 0.25 },
      ],
    });

    setMa100Data({
      labels,
      datasets: [
        { label: "Actual Price", data: actual, borderColor: "#60a5fa", tension: 0.25 },
        { label: "100-Day MA", data: ma100, borderColor: "#f59e0b", tension: 0.25 },
      ],
    });

    setLogs(
      `49/49 — 5s 112ms/step — loss: 0.0176\nEpoch 7/10\n49/49 — 2s 105ms/step — loss: 0.0126\nEpoch 8/10\n49/49 — 2s 071ms/step — loss: 0.0150\nEpoch 9/10\n49/49 — 4s 131ms/step — loss: 0.0120\nEpoch 10/10\n49/49 — 5s 091ms/step — loss: 0.0147\n\nModel Accuracy: 93.73%\n\nFinal Verdict: The model predicts a downward trend.`
    );

    setHasResult(true);
  };

  const Card = ({ title, icon, children }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-[#1e293b] p-6 rounded-2xl shadow-lg hover:shadow-xl transition"
    >
      <div className="flex items-center gap-3 mb-4 border-b border-slate-700 pb-2">
        {icon}
        <h2 className="text-base font-semibold text-slate-200">{title}</h2>
      </div>
      {children}
    </motion.div>
  );

  return (
    <div className="background: linear-gradient(180deg, #05080a, #0b0f12 80%) min-h-screen text-white p-8">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-4xl font-extrabold text-cyan-400 text-center mb-2"
      >
        Stock Price Predictor
      </motion.h1>
      <p className="text-center text-slate-400 mb-10 text-lg">
        AI-powered stock analysis & prediction dashboard
      </p>

      <div className="flex justify-center mb-12">
        <input
          type="text"
          placeholder="Enter stock symbol (e.g. AAPL)"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          className="w-full max-w-md px-4 py-3 rounded-l-xl bg-[#1e293b] text-white border border-slate-600 focus:ring-2 focus:ring-cyan-500 focus:outline-none"
        />
        <button
          onClick={handlePredict}
          className="px-6 py-3 bg-cyan-500 hover:bg-cyan-600 rounded-r-xl font-semibold transition"
        >
          Predict
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <Card title={`${symbol.toUpperCase()} Price Prediction`} icon={<BarChart3 size={20} className="text-cyan-400" />}>
          <div className="h-72">{hasResult && predData && <Line data={predData} options={options} />}</div>
        </Card>

        <Card title={`${symbol.toUpperCase()} 100 & 200 Day MAs`} icon={<Activity size={20} className="text-yellow-400" />}>
          <div className="h-72">{hasResult && maData && <Line data={maData} options={options} />}</div>
        </Card>

        <Card title={`${symbol.toUpperCase()} 100 Day MA`} icon={<Cpu size={20} className="text-green-400" />}>
          <div className="h-72">{hasResult && ma100Data && <Line data={ma100Data} options={options} />}</div>
        </Card>
      </div>

      <Card title="Model Output Console" icon={<Cpu size={20} className="text-cyan-300" />}>
        <div className="bg-black text-green-400 font-mono p-5 rounded-lg h-80 overflow-y-auto text-sm whitespace-pre-wrap">
          {logs || "Logs will appear here after prediction..."}
        </div>
      </Card>
    </div>
  );
}
