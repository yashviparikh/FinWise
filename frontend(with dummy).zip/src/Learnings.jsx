// import react from 'react';
// import './Learnings.css';
// function Learnings(){
//    const news=[
//     {
//       headline:"TCS shares surge 4% after strong Q1 results",
//       summary: "TCS posted better-than-expected profits. Investors responded positively.",
//       sentiment: "Positive",
//       learn: "Earnings beats often cause short-term rallies."
//     },
//     {
//       headline: "Infosys shares drop 2% after weak guidance",
//       summary: "Lower revenue guidance worried investors.",
//       sentiment: "Negative",
//       learn: "Weak future outlook can push share prices down."
//     }
//    ];
//    return(
//     <div className='learning-container'>
//         <h2>Learning Hub</h2>
//         <div className='cards-container'>
//            {/* card 1 */}
//            <div className='card terminologies'>
//             <h3>Basic Terms and Terminologies</h3>
//             <p>Learn the essential stock market terms and definition</p>
//             <button className='learn-btn'>Learn More</button>
//            </div>
//            {/* card2 */}
//            <div className='card'>
//             <h3>News Headlines</h3>
//             {news.map((item,index)=>(
//                 <div key={index} className='news-item'>
//                     <h4>{item.headline}</h4>
//                     <p>{item.summary}</p>
//                     <p className={`sentiment ${item.sentiment.toLowerCase()}`}>Sentiment:{item.sentiment}</p>
//                     <p className='learn-tip'>Tip:{item.learn}</p>
//                 </div>
//             ))}
//            </div>
//         </div>
//     </div>
//    );
// }
// export default Learnings;

import React, { useState } from "react";
import "./Learnings.css";

function Learning() {
  const [selectedTopic, setSelectedTopic] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [hoveredNews, setHoveredNews] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const learningTopics = [
    {
      id: 1,
      icon: "📈",
      title: "What is Stock?",
      summary: "Learn the fundamentals of stocks and equity ownership.",
      content: `
        <h3>Understanding Stocks</h3>
        <p>A stock represents a share in the ownership of a company. When you buy stock, you become a partial owner of that company and gain rights to its earnings and assets.</p>
        <ul>
          <li><strong>Ownership:</strong> Buying stock means owning a fraction of the company.</li>
          <li><strong>Dividends:</strong> Some companies share profits with shareholders.</li>
          <li><strong>Capital Gains:</strong> Profit earned by selling shares at a higher price.</li>
          <li><strong>Market Cap:</strong> Total value of all outstanding shares.</li>
        </ul>
        <div class="highlight">Tip: Stocks are ideal for long-term wealth creation.</div>
      `
    },
    {
      id: 2,
      icon: "💹",
      title: "How Trading Works",
      summary: "Understand the mechanics of buying and selling stocks.",
      content: `
        <h3>How Stock Trading Works</h3>
        <p>Trading involves buying and selling shares of publicly listed companies through stock exchanges.</p>
        <ul>
          <li><strong>Market Order:</strong> Buys/sells immediately at the current price.</li>
          <li><strong>Limit Order:</strong> Executes only when your target price is met.</li>
          <li><strong>Stop-Loss Order:</strong> Minimizes losses by selling when price falls.</li>
          <li><strong>After-Hours Trading:</strong> Trades made outside standard exchange hours.</li>
        </ul>
        <div class="highlight">Pro Tip: Always use stop-loss orders to manage risk!</div>
      `
    },
    {
      id: 3,
      icon: "🛡️",
      title: "Risk Management",
      summary: "Learn how to protect your investments and manage risk.",
      content: `
        <h3>Risk Management Strategies</h3>
        <p>Managing risk is critical for protecting your portfolio and achieving steady returns.</p>
        <ul>
          <li><strong>Diversification:</strong> Spread investments across sectors.</li>
          <li><strong>Position Sizing:</strong> Never invest too much in one asset.</li>
          <li><strong>Stop-Loss Orders:</strong> Protect capital by limiting downside.</li>
          <li><strong>Portfolio Rebalancing:</strong> Adjust allocations regularly.</li>
        </ul>
        <div class="highlight warning">Warning: High-risk trades without risk management can lead to significant losses.</div>
      `
    },
    {
      id: 4,
      icon: "🌱",
      title: "Long Term Investment",
      summary: "Discover the power of long-term wealth building.",
      content: `
        <h3>Why Long-Term Investing Works</h3>
        <p>Holding quality assets for years helps maximize returns and reduce volatility.</p>
        <ul>
          <li><strong>Compounding:</strong> Earnings generate further earnings over time.</li>
          <li><strong>Lower Taxes:</strong> Long-term capital gains are taxed less.</li>
          <li><strong>Reduced Stress:</strong> Less focus on daily market fluctuations.</li>
          <li><strong>Stability:</strong> Minimizes the effect of short-term volatility.</li>
        </ul>
        <div class="highlight success">Remember: Time in the market beats timing the market.</div>
      `
    }
  ];

  const newsHeadlines = [
    {
      id: 1,
      title: "Federal Reserve Signals Potential Rate Cuts in 2024",
      summary: "Fed officials hint at possible interest rate reductions amid cooling inflation",
      category: "Economy",
      sentiment: "Positive",
      time: "2 hours ago",
      learn: "Rate cuts stimulate growth, boosting stocks but lowering bond yields."
    },
    {
      id: 2,
      title: "Tech Giants Report Strong Q4 Earnings Despite Market Concerns",
      summary: "Apple, Microsoft, and Google exceed analyst expectations",
      category: "Earnings",
      sentiment: "Positive",
      time: "4 hours ago",
      learn: "Strong earnings typically drive stock prices up."
    },
    {
      id: 3,
      title: "Oil Prices Surge on Middle East Tensions",
      summary: "Crude oil jumps 3% as geopolitical concerns mount",
      category: "Commodities",
      sentiment: "Negative",
      time: "6 hours ago",
      learn: "Rising oil prices may push inflation higher and hurt transportation stocks."
    },
    {
      id: 4,
      title: "Electric Vehicle Sales Hit Record High in 2023",
      summary: "Tesla and BYD lead EV adoption globally",
      category: "Automotive",
      sentiment: "Positive",
      time: "8 hours ago",
      learn: "EV sector growth benefits automakers, battery companies, and infrastructure firms."
    },
    {
      id: 5,
      title: "AI Stocks Rally on ChatGPT Enterprise Launch",
      summary: "AI companies surge on enterprise adoption expectations",
      category: "Technology",
      sentiment: "Positive",
      time: "10 hours ago",
      learn: "AI adoption drives long-term growth in tech stocks."
    },
    {
      id: 6,
      title: "Banking Sector Faces Regulatory Scrutiny",
      summary: "Stricter rules could affect bank profitability",
      category: "Banking",
      sentiment: "Negative",
      time: "12 hours ago",
      learn: "Tighter regulations may lower lending and reduce bank stock performance."
    },
    {
      id: 7,
      title: "Cryptocurrency Market Shows Signs of Recovery",
      summary: "Bitcoin and Ethereum gain momentum after volatility",
      category: "Crypto",
      sentiment: "Positive",
      time: "14 hours ago",
      learn: "Regulatory clarity boosts institutional adoption and price stability."
    },
    {
      id: 8,
      title: "Healthcare Stocks Rise on Drug Approval News",
      summary: "FDA approves breakthrough treatments",
      category: "Healthcare",
      sentiment: "Positive",
      time: "16 hours ago",
      learn: "FDA approvals can significantly increase pharma stock valuations."
    },
    {
      id: 9,
      title: "Inflation Data Shows Continued Cooling Trend",
      summary: "Consumer Price Index drops to 3.2% YoY",
      category: "Economy",
      sentiment: "Positive",
      time: "18 hours ago",
      learn: "Cooling inflation reduces pressure on central banks and supports spending."
    },
    {
      id: 10,
      title: "Renewable Energy Investments Reach $2 Trillion",
      summary: "Clean energy adoption accelerates globally",
      category: "Energy",
      sentiment: "Positive",
      time: "20 hours ago",
      learn: "Green energy investments create long-term opportunities in clean tech."
    }
  ];

  const openModal = (topic) => {
    setSelectedTopic(topic);
    setShowModal(true);
  };

  const closeModal = () => {
    setSelectedTopic(null);
    setShowModal(false);
  };

  const handleNewsHover = (news, e) => {
    setHoveredNews(news);
    setMousePos({ x: e.clientX, y: e.clientY });
  };

  const handleNewsLeave = () => setHoveredNews(null);

  return (
    <div className="learning-container">
      {/* Learning Section */}
      <h2 className="section-title">Basic Terms and Terminologies</h2>
      <div className="learning-grid">
        {learningTopics.map((topic) => (
          <div className="learning-card" key={topic.id}>
            <div className="icon">{topic.icon}</div>
            <h3>{topic.title}</h3>
            <p>{topic.summary}</p>
            <button onClick={() => openModal(topic)}>Learn More</button>
          </div>
        ))}
      </div>

      {/* News Section */}
      <h2 className="section-title">Top 10 News Headlines</h2>
      <div className="news-section">
        {newsHeadlines.map((news) => (
          <div
            className="news-item"
            key={news.id}
            onMouseEnter={(e) => handleNewsHover(news, e)}
            onMouseLeave={handleNewsLeave}
          >
            <div className="news-header">
              <span className={`news-category ${news.category.toLowerCase()}`}>
                {news.category}
              </span>
              <span
                className={`news-sentiment ${
                  news.sentiment === "Positive" ? "positive" : "negative"
                }`}
              >
                {news.sentiment}
              </span>
              <span className="news-time">{news.time}</span>
            </div>
            <h3>{news.title}</h3>
            <p>{news.summary}</p>
          </div>
        ))}
      </div>

      {/* Hover Popup */}
      {hoveredNews && (
        <div
          className="hover-popup"
          style={{
            left: mousePos.x + 20,
            top: mousePos.y + 10,
          }}
        >
          <h4>{hoveredNews.title}</h4>
          <p><strong>Summary:</strong> {hoveredNews.summary}</p>
          <p><strong>Learn:</strong> {hoveredNews.learn}</p>
          <p>
            <strong>Sentiment:</strong>{" "}
            <span
              className={`news-sentiment ${
                hoveredNews.sentiment === "Positive" ? "positive" : "negative"
              }`}
            >
              {hoveredNews.sentiment}
            </span>
          </p>
        </div>
      )}

      {/* Modal */}
{showModal && selectedTopic && (
  <div className="modal-backdrop" onClick={closeModal}>
    <div
      className="modal-content"
      onClick={(e) => e.stopPropagation()}
    >
      <div
        dangerouslySetInnerHTML={{ __html: selectedTopic.content }}
      />
      <button className="close-btn" onClick={closeModal}>
        Close
      </button>
    </div>
  </div>
)}

    </div>
  );
}

export default Learning;
