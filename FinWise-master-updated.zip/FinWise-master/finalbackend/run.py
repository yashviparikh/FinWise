from invest import create_app

# The app is created as usual
app = create_app()

# --- REPLACE your old "fix-sectors" command with THIS ONE ---
@app.cli.command("debug-sectors")
def debug_sectors_command():
    """
    A verbose, one-time command to diagnose and fix missing sectors in the portfolio.
    """
    from invest.models import Portfolio, db
    from invest.portfolio import get_sector_from_api
    import sys

    print("--- Starting Sector Debug & Fix Script ---")
    
    try:
        # We need the app context to interact with the database
        with app.app_context():
            print("1. Successfully entered application context.")
            
            # Find all portfolio items where the sector has not been set yet
            portfolios_to_update = Portfolio.query.filter(Portfolio.sector.is_(None)).all()
            
            if not portfolios_to_update:
                print("\n✅ RESULT: No portfolios found with a NULL sector. All entries seem to be processed. Exiting.")
                sys.exit(0)

            print(f"\n2. Found {len(portfolios_to_update)} portfolio entries to update.")
            
            updated_count = 0
            for p in portfolios_to_update:
                stock_name = p.stockname
                print(f"\n--- Processing: {stock_name} ---")
                
                print(f"  - Calling get_sector_from_api('{stock_name}')...")
                sector_from_api = get_sector_from_api(stock_name)
                print(f"  - API returned: '{sector_from_api}'")
                
                if sector_from_api and sector_from_api != "Other":
                    p.sector = sector_from_api
                    db.session.add(p)
                    print(f"  - Staged update for {stock_name} to '{p.sector}'.")
                    updated_count += 1
                else:
                    print(f"  - SKIPPED database update for {stock_name} because API returned '{sector_from_api}'.")

            if updated_count > 0:
                print("\n3. Attempting to commit changes to the database...")
                db.session.commit()
                print("✅ COMMIT SUCCESSFUL!")
            else:
                print("\n3. No valid sectors were found, so no changes were committed to the database.")

            print("\n--- Script Finished ---")

    except Exception as e:
        print(f"\n❌ AN ERROR OCCURRED: {e}")
        # Use a new session for rollback to be safe
        with app.app_context():
             db.session.rollback()
        print("   Database changes have been rolled back.")
# -------------------------------------------------------------------

# This part runs the app when you execute "flask run" or "python run.py"
if __name__ == "__main__":
    app.run(debug=True)

