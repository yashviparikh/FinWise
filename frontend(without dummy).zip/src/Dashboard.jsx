import React, { useMemo, useState, useRef } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Sector,
} from "recharts";
import {
  FiTrendingUp,
  FiTrendingDown,
  FiPieChart,
  FiActivity,
  FiDownload,
} from "react-icons/fi";
import { BsWallet2 } from "react-icons/bs";
import { MdInsights } from "react-icons/md";
import { motion } from "framer-motion";
import CountUp from "react-countup";
import "./Dashboard.css";

export default function Dashboard() {
  // ✅ Fixed wallet at 10000, everything else null/empty
  const wallet = 10000;
  const portfolio = [];
  const transactions = [];
  const allStocks = [];

  const [tf, setTf] = useState("YTD");
  const [activePieIndex, setActivePieIndex] = useState(-1);
  const [activePiePayload, setActivePiePayload] = useState(null);
  const hoverPanelRef = useRef(null);

  // --- Derived metrics all null/0 ---
  const totalInvested = 0;
  const totalValue = 0;
  const totalPL = 0;
  const holdingsCount = 0;
  const dayChange = 0;

  const fmtCurrency = (n) =>
    (n ?? 0).toLocaleString(undefined, {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 2,
    });

  // --- Chart months ---
  const months = [
    "Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec",
  ];

  // --- Portfolio value chart (all null values) ---
  const portfolioValueSeries = months.map((m) => ({
    month: m,
    value: null,
  }));

  // --- P&L chart (all null values) ---
  const plSeries = months.map((m) => ({
    month: m,
    pnl: null,
  }));

  // --- Sector split (all zero/null) ---
  const sectorSplit = [
    { name: "Tech", value: 0, qty: 0, invested: 0, nowValue: 0 },
    { name: "Finance", value: 0, qty: 0, invested: 0, nowValue: 0 },
    { name: "Healthcare", value: 0, qty: 0, invested: 0, nowValue: 0 },
    { name: "Energy", value: 0, qty: 0, invested: 0, nowValue: 0 },
  ];

  const pieColors = [
    "#2ED3A3",
    "#7C8CFF",
    "#54C5FF",
    "#00E676",
    "#FDBA8C",
    "#FF6B6B",
    "#FFD27F",
  ];

  // --- Top performers (empty) ---
  const topPerformers = [];

  // --- CSV export disabled ---
  const exportCSV = () => {
    alert("No data to export");
  };

  // --- Pie hover ---
  function renderActiveShape(props) {
    const {
      cx, cy, midAngle, innerRadius, outerRadius,
      startAngle, endAngle, fill, payload,
    } = props;
    return (
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 8}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
    );
  }

  const onPieEnter = (_, index) => {
    setActivePieIndex(index);
    setActivePiePayload(sectorSplit[index] || null);
  };
  const onPieLeave = () => {
    setActivePieIndex(-1);
    setActivePiePayload(null);
  };
  const [hoverPos, setHoverPos] = useState({ x: 0, y: 0 });
  const onPieMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setHoverPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  // --- UI ---
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="dash page-bg"
    >
      {/* Header */}
      <div className="dash__header">
        <div>
          <h1 className="dash__title">Dashboard</h1>
          <p className="dash__subtitle">
            Your trading overview and performance metrics
          </p>
        </div>
        <div className="header-tools">
          <div className="wallet-pill">
            <BsWallet2 />
            <span>
              Wallet: <strong>{fmtCurrency(wallet)}</strong>
            </span>
          </div>
          <button
            className="export-btn"
            onClick={() => exportCSV("portfolio")}
            title="Export portfolio CSV"
          >
            <FiDownload /> Export CSV
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid--4">
        <MetricCard
          icon={<BsWallet2 />}
          label="Portfolio Value"
          value={fmtCurrency(totalValue)}
          sub={`Total invested: ${fmtCurrency(totalInvested)}`}
        />
        <MetricCard
          icon={<MdInsights />}
          label="Total P&L"
          value={fmtCurrency(totalPL)}
          sub="0.00% return"
          tone="neutral"
        />
        <MetricCard
          icon={<FiPieChart />}
          label="Holdings"
          value={<div className="metric__value">{holdingsCount}</div>}
          sub="Active positions"
        />
        <MetricCard
          icon={<FiActivity />}
          label="Day Change"
          value={fmtCurrency(dayChange)}
          sub="0.00% today"
          tone="neutral"
        />
      </div>

      {/* Timeframe controls */}
      <div className="chart-controls">
        <div className="tf-buttons">
          {["1M", "YTD", "1Y"].map((t) => (
            <button
              key={t}
              className={`tf-btn ${tf === t ? "active" : ""}`}
              onClick={() => setTf(t)}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid--2">
        <ChartCard title="Portfolio Value" tag="—" tagTone="neutral">
          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={portfolioValueSeries}>
              <CartesianGrid stroke="rgba(255,255,255,0.03)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#AAB8C7" }} />
              <YAxis tick={{ fill: "#AAB8C7" }} />
              <Tooltip formatter={() => "—"} />
              <Area
                type="monotone"
                dataKey="value"
                stroke="#26E07F"
                fill="rgba(38,224,127,0.25)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Profit & Loss" tag="—" tagTone="neutral">
          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={plSeries}>
              <CartesianGrid stroke="rgba(255,255,255,0.03)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#AAB8C7" }} />
              <YAxis tick={{ fill: "#AAB8C7" }} />
              <Tooltip formatter={() => "—"} />
              <Area
                type="monotone"
                dataKey="pnl"
                stroke="#7C8CFF"
                fill="rgba(124,140,255,0.25)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Lower row */}
      <div className="grid grid--3">
        {/* Top performers */}
        <Card title="Top Performers">
          <div className="empty">
            <div className="empty__icon">📈</div>
            <div>No holdings to display</div>
          </div>
        </Card>

        {/* Investment split */}
        <Card title="Investment Split">
          <div className="pie-wrapper">
            <div className="pie-3d-viewport" onMouseMove={onPieMouseMove}>
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={sectorSplit}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={58}
                    outerRadius={110}
                    paddingAngle={4}
                    startAngle={90}
                    endAngle={-270}
                    activeIndex={activePieIndex}
                    activeShape={renderActiveShape}
                    onMouseEnter={onPieEnter}
                    onMouseLeave={onPieLeave}
                  >
                    {sectorSplit.map((entry, index) => (
                      <Cell
                        key={`c-${index}`}
                        fill={pieColors[index % pieColors.length]}
                      />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="legend legend-grid">
              {sectorSplit.map((s, i) => (
                <div key={`${s.name}-${i}`} className="legend__row">
                  <span
                    className="dot"
                    style={{ background: pieColors[i % pieColors.length] }}
                  />
                  <div className="legend__label">
                    <div className="legend__name">{s.name}</div>
                    <div className="legend__val">{s.value}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Recent transactions */}
        <Card title="Recent Transactions">
          <div className="empty">
            <div className="empty__icon">🧾</div>
            <div>No recent activity</div>
          </div>
        </Card>
      </div>
    </motion.div>
  );
}

/* --- Small UI components --- */
function MetricCard({ icon, label, value, sub, tone = "neutral" }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className={`metric ${tone} hover-lift`}
    >
      <div className="metric__icon">{icon}</div>
      <div className="metric__body">
        <div className="metric__label">{label}</div>
        <div className="metric__value">{value}</div>
        {sub && <div className="metric__sub">{sub}</div>}
      </div>
    </motion.div>
  );
}

function ChartCard({ title, tag, tagTone = "neutral", children }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="chart-card hover-lift"
    >
      <div className="card__head">
        <h3>{title}</h3>
        {tag && <span className={`tag ${tagTone}`}>{tag}</span>}
      </div>
      <div className="card__body">{children}</div>
    </motion.div>
  );
}

function Card({ title, children }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="chart-card hover-lift"
    >
      <div className="card__head" style={{ marginBottom: 12 }}>
        <h3>{title}</h3>
      </div>
      <div className="card__body">{children}</div>
    </motion.div>
  );
}
