from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
import bcrypt
import firebase_admin
from firebase_admin import auth as firebase_auth, credentials
import os
import json
import random
import datetime

app = Flask(__name__)

# CORS config
# CORS config - allow your frontend at localhost:3000 (and 5173 if you sometimes use Vite)
FRONTEND_ORIGINS = ["http://localhost:3000", "http://localhost:5173"]
CORS(app, resources={r"/*": {"origins": FRONTEND_ORIGINS}}, supports_credentials=True)


# MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["th3ee"]
users = db["users"]

# Firebase Admin init (optional)
sa_path = os.path.join(os.path.dirname(__file__), "serviceAccountKey.json")
if os.path.exists(sa_path):
    try:
        cred = credentials.Certificate(sa_path)
        firebase_admin.initialize_app(cred)
        with open(sa_path, "r") as f:
            sa = json.load(f)
        print("Firebase Admin initialized for project:", sa.get("project_id"))
    except Exception as e:
        print("Firebase Admin init error:", e)
else:
    print("serviceAccountKey.json not found (ok for dev OTP flow).")

# Helpers
def gen_otp(n=6):
    return ''.join(str(random.randint(0,9)) for _ in range(n))

def normalize_phone(phone):
    if not phone:
        return None
    s = str(phone).strip()
    if s.startswith('+'):
        return s
    digits = ''.join(ch for ch in s if ch.isdigit())
    if len(digits) == 10:
        return '+91' + digits
    return '+' + digits

def get_user_query(data):
    return {"phone": data.get("phone")} if data.get("phone") else {"email": data.get("email")}

# ---------------------- SIGNUP ----------------------
@app.route('/signup', methods=['POST'])
def signup():
    data = request.json or {}
    name = data.get('name')
    phone = data.get('phone')
    password = data.get('password')
    if not phone or not password:
        return jsonify({"status":"fail","message":"phone and password required"}), 400
    phone_norm = normalize_phone(phone)
    if users.find_one({"phone": phone_norm}):
        return jsonify({"status": "fail", "message": "User already exists"}), 409
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    users.insert_one({"name": name, "phone": phone_norm, "password": hashed, "cart": []})
    return jsonify({"status": "success", "message": "Signup successful"})

# ---------------------- LOGIN ----------------------
@app.route('/login', methods=['OPTIONS','POST'])
def login():
    if request.method == 'OPTIONS':
        return ('', 200)
    try:
        data = request.json or {}
        print("[DEBUG /login] payload:", data)
        phone = str(data.get('phone') or '')
        password = data.get('password') or ''
        phone_norm = normalize_phone(phone) if phone else phone
        print("[DEBUG /login] phone_norm:", phone_norm)

        user = users.find_one({"phone": phone_norm}) or users.find_one({"phone": phone})
        if not user:
            print("[DEBUG /login] user not found for phone:", phone_norm, "or", phone)
            return jsonify({"status":"fail","message":"Invalid credentials"}), 401

        stored = user.get('password', None)
        print("[DEBUG /login] stored password raw repr:", repr(stored), "type:", type(stored))

        # Normalize stored -> bytes for bcrypt
        stored_bytes = None
        try:
            # If it's already bytes-like
            if isinstance(stored, (bytes, bytearray)):
                stored_bytes = bytes(stored)
            # bson.binary.Binary -> bytes(...) works
            else:
                stored_bytes = bytes(stored)
        except Exception:
            try:
                # fallback: encode string
                if isinstance(stored, str):
                    stored_bytes = stored.encode('utf-8')
            except Exception as e:
                print("[DEBUG /login] failed to convert stored password to bytes:", type(e).__name__, e)
                stored_bytes = None

        print("[DEBUG /login] stored_bytes type:", type(stored_bytes), "len:", len(stored_bytes) if stored_bytes else None)

        if not stored_bytes:
            print("[DEBUG /login] no valid stored password bytes")
            return jsonify({"status":"fail","message":"Server error (bad stored password)"}), 500

        if bcrypt.checkpw(password.encode('utf-8'), stored_bytes):
            return jsonify({
                "status": "success",
                "message": "Login successful",
                "user": {
                    "name": user.get("name", ""),
                    "phone": user.get("phone"),
                    "cart": user.get("cart", [])
                }
            })
        else:
            print("[DEBUG /login] password mismatch for", phone_norm)
            return jsonify({"status":"fail","message":"Invalid credentials"}), 401

    except Exception as e:
        import traceback
        print("Exception in /login:", type(e).__name__, str(e))
        traceback.print_exc()
        return jsonify({"status":"fail","message":"Server error"}), 500

# ---------------------- GOOGLE LOGIN ----------------------
@app.route('/google-login', methods=['OPTIONS','POST'])
def google_login():
    if request.method == 'OPTIONS':
        return ('', 200)
    data = request.json or {}
    id_token = data.get('idToken') or data.get('id_token') or data.get('token')
    if not id_token:
        return jsonify({"status":"fail","message":"No idToken provided"}), 400
    try:
        decoded = firebase_auth.verify_id_token(id_token)
        uid = decoded.get('uid')
        email = decoded.get('email')
        name = decoded.get('name') or (email.split('@')[0] if email else 'User')
        user = users.find_one({"firebase_uid": uid}) or users.find_one({"email": email})
        if not user:
            new_user = {"name": name, "email": email, "firebase_uid": uid, "cart": []}
            users.insert_one(new_user)
            user = users.find_one({"firebase_uid": uid})
        user_out = {"name": user.get("name"), "email": user.get("email"), "cart": user.get("cart", [])}
        return jsonify({"status":"success","message":"Google login OK","user":user_out})
    except Exception as e:
        print("Token verify error:", type(e).__name__, str(e))
        return jsonify({"status":"fail","message":"Invalid ID token","error": str(e)}), 401

# ---------------------- CART APIs ----------------------
@app.route('/add-to-cart', methods=['POST'])
def add_to_cart():
    data = request.json or {}
    item = data.get('item')
    if not item:
        return jsonify({"status":"fail","message":"No item provided"}), 400
    query = get_user_query(data)
    user = users.find_one(query)
    if not user:
        return jsonify({"status":"fail","message":"User not found"}), 404
    users.update_one(query, {"$push": {"cart": item}})
    return jsonify({"status":"success","message":"Item added to cart"})

@app.route('/get-cart', methods=['POST'])
def get_cart():
    data = request.json or {}
    query = get_user_query(data)
    user = users.find_one(query)
    if not user:
        return jsonify({"status":"fail","message":"User not found"}), 404
    return jsonify({"status":"success","cart": user.get("cart", [])})

@app.route('/remove-from-cart', methods=['POST'])
def remove_from_cart():
    data = request.json or {}
    item_id = data.get('item_id')
    if not item_id:
        return jsonify({"status":"fail","message":"Item ID is required"}), 400
    query = get_user_query(data)
    user = users.find_one(query)
    if not user:
        return jsonify({"status":"fail","message":"User not found"}), 404
    users.update_one(query, {"$pull": {"cart": {"id": item_id}}})
    return jsonify({"status":"success","message":"Item removed from cart"})

@app.route('/update-cart-item', methods=['POST'])
def update_cart_item():
    data = request.json or {}
    item_id = data.get("item_id")
    key = data.get("key")
    value = data.get("value")
    if not item_id or not key:
        return jsonify({"status":"fail","message":"Item ID and key are required"}), 400
    query = get_user_query(data)
    update_result = users.update_one({**query, "cart.id": item_id}, {"$set": {f"cart.$.{key}": value}})
    if update_result.modified_count:
        return jsonify({"status":"success","message":"Cart item updated"})
    return jsonify({"status":"fail","message":"Item not found"}), 404

@app.route('/clear-cart', methods=['POST'])
def clear_cart():
    data = request.json or {}
    query = get_user_query(data)
    result = users.update_one(query, {"$set": {"cart": []}})
    if result.modified_count:
        return jsonify({"status":"success","message":"Cart cleared"}), 200
    return jsonify({"status":"fail","message":"User not found"}), 404

# ---------------------- OTP / forgot-password helper endpoints ----------------------
@app.route('/send-otp', methods=['OPTIONS','POST'])
def send_otp():
    if request.method == 'OPTIONS':
        return ('', 200)
    data = request.json or {}
    phone_raw = data.get('phone') or data.get('phoneNumber') or data.get('mobile')
    phone = normalize_phone(phone_raw)
    if not phone:
        return jsonify({"status":"fail","message":"phone required"}), 400
    otp = gen_otp(6)
    otp_ts = datetime.datetime.utcnow()
    # Ensure phone is stored on upserted doc (avoids missing phone field)
    users.update_one(
        {"phone": phone},
        {"$set": {"phone": phone, "otp": otp, "otp_ts": otp_ts}},
        upsert=True
    )
    print(f"[DEV OTP] phone={phone} otp={otp} (valid 10 minutes)")
    return jsonify({"status":"success","message":"OTP generated and saved (dev)."}), 200

@app.route('/verify-otp', methods=['OPTIONS','POST'])
def verify_otp():
    if request.method == 'OPTIONS':
        return ('', 200)
    data = request.json or {}
    phone_raw = data.get('phone') or data.get('phoneNumber') or data.get('mobile')
    otp = str(data.get('otp') or '').strip()
    phone = normalize_phone(phone_raw)
    if not phone or not otp:
        return jsonify({"status":"fail","message":"phone and otp required"}), 400
    user = users.find_one({"phone": phone})
    if not user or 'otp' not in user:
        return jsonify({"status":"fail","message":"No OTP found for this number"}), 404
    otp_ts = user.get('otp_ts')
    if not otp_ts:
        return jsonify({"status":"fail","message":"No OTP timestamp found"}), 400
    now = datetime.datetime.utcnow()
    if isinstance(otp_ts, str):
        try:
            otp_ts = datetime.datetime.fromisoformat(otp_ts)
        except Exception:
            return jsonify({"status":"fail","message":"Invalid OTP timestamp"}), 400
    if (now - otp_ts).total_seconds() > 600:
        return jsonify({"status":"fail","message":"OTP expired"}), 400
    if user.get('otp') != otp:
        return jsonify({"status":"fail","message":"Invalid OTP"}), 401

    # DON'T remove otp yet — keep it until password update.
    # Mark the verification so the client can proceed.
    users.update_one(
        {"phone": phone},
        {"$set": {"otp_verified": True, "otp_verified_ts": now}}
    )
    return jsonify({"status":"success","message":"OTP verified"}), 200

@app.route('/forgot-password', methods=['OPTIONS','POST'])
def forgot_password():
    if request.method == 'OPTIONS':
        return ('', 200)
    data = request.json or {}
    phone_raw = data.get('phone') or data.get('phoneNumber') or data.get('mobile')
    otp = str(data.get('otp') or '').strip()
    new_password = data.get('newPassword') or data.get('password')
    phone = normalize_phone(phone_raw)
    print("[DEBUG forgot_password] phone_raw:", phone_raw)
    print("[DEBUG forgot_password] normalized phone:", phone)
    print("[DEBUG forgot_password] payload keys:", list(data.keys()))
    if not phone or not otp or not new_password:
        return jsonify({"status":"fail", "message":"phone, otp and newPassword required"}), 400
    user = users.find_one({"phone": phone})
    if not user or 'otp' not in user:
        return jsonify({"status":"fail", "message":"No OTP found for this number"}), 404
    otp_ts = user.get('otp_ts')
    if not otp_ts:
        return jsonify({"status":"fail","message":"No OTP timestamp found"}), 400
    now = datetime.datetime.utcnow()
    if isinstance(otp_ts, str):
        try:
            otp_ts = datetime.datetime.fromisoformat(otp_ts)
        except Exception:
            return jsonify({"status":"fail","message":"Invalid OTP timestamp"}), 400
    if (now - otp_ts).total_seconds() > 600:
        return jsonify({"status":"fail","message":"OTP expired"}), 400
    if user.get('otp') != otp:
        return jsonify({"status":"fail","message":"Invalid OTP"}), 401

    try:
        hashed = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())
        users.update_one(
            {"phone": phone},
            {"$set": {"password": hashed}, "$unset": {"otp": "", "otp_ts": "", "otp_verified": "", "otp_verified_ts": ""}}
        )
        return jsonify({"status":"success", "message":"Password updated successfully"}), 200
    except Exception as e:
        print("Password update error:", e)
        return jsonify({"status":"fail", "message":"Failed to update password"}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
